#include "desktop.hpp"
#include "language.hpp"
#include "media_job.hpp"
#include "player.hpp"
#include <algorithm>
#include <chrono>
#include <commctrl.h>
#include <commdlg.h>
#include <dwmapi.h>
#include <filesystem>
#include <fstream>
#include <gdiplus.h>
#include <initguid.h>
#include <iomanip>
#include <knownfolders.h>
#include <powersetting.h>
#include <powrprof.h>
#include <psapi.h>
#include <shellapi.h>
#include <shlobj.h>
#include <sstream>
#include <string>
#include <uxtheme.h>
#include <vector>
#include <windows.h>
#include <wtsapi32.h>

namespace {
constexpr UINT WM_TRAY = WM_APP + 1, WM_CHECK = WM_APP + 2;
enum {
  ID_CHOOSE = 100,
  ID_APPLY,
  ID_PREVIEW,
  ID_PAUSE,
  ID_STOP,
  ID_ORIGINAL,
  ID_FPS,
  ID_AUTO,
  ID_VOLUME,
  ID_SHOW,
  ID_EXIT,
  ID_ABOUT,
  ID_ALTERNATIVE,
  ID_LOGS,
  ID_FILES,
  ID_LANGUAGE,
  ID_PT = 2001,
  ID_EN = 2002
};
HINSTANCE instance;
HWND window = nullptr, video = nullptr, worker = nullptr, fileBox = nullptr,
     statusBox = nullptr, detailBox = nullptr, fpsBox = nullptr,
     autoBox = nullptr, volumeBox = nullptr, pauseButton = nullptr;
HFONT normalFont = nullptr, titleFont = nullptr;
HBRUSH bg = nullptr;
Player player;
DesktopTarget desktopTarget;
MediaJob media;
enum class Intent { Select, Desktop, Preview, Alternative };
Intent pendingIntent = Intent::Select;
bool converting = false, alternative = false, applicationPending = false,
     fileLoaded = false;
ULONGLONG applicationStarted = 0;
uint64_t loadedFrameMark = 0;
std::wstring checkedPath, convertedFolder;
WIN32_FILE_ATTRIBUTE_DATA checkedStamp{};
pv::VideoSize checkedSize;
void requestVideo(Intent intent);
void apply(bool asPreview);
void useOverlay(bool manual);
pv::PausePolicy policy;
std::wstring baseDir, iniPath, selected, lastError;
std::wstring message = L"Seu papel de parede original está preservado.";
std::wstring renderInfo = L"Recomendado: H.264, 720p/1080p, até 30 FPS.";
int fps = 30, volume = 0;
bool preview = false, playing = false, lastPause = false, quitting = false,
     trayAdded = false;
HWINEVENTHOOK foregroundHook = nullptr;
HPOWERNOTIFY powerNotify = nullptr;
UINT taskbarCreated = 0;
uint64_t lastPresents = 0;
ULONGLONG lastTelemetry = 0, lastRecover = 0;
double actualFps = 0, cpu = 0;
unsigned long long lastCpu = 0, lastWall = 0;
NOTIFYICONDATAW tray{sizeof(tray)};
bool diagnosticSoftware = false;
bool selftest = false;
bool restartRequested = false;
ULONGLONG testStart = 0;
uint64_t pausedFrames = 0, pauseStable = 0, pauseDrift = 0, resumeMark = 0;
bool testPaused = false, testResumed = false, pauseMeasured = false,
     testPassed = false;
std::wstring fromUtf8(const std::string &s) {
  if (s.empty())
    return {};
  int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()),
                              nullptr, 0);
  std::wstring r(n, L'\0');
  MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()),
                      r.data(), n);
  return r;
}
std::string toUtf8(const std::wstring &s) {
  int n = WideCharToMultiByte(CP_UTF8, 0, s.data(), static_cast<int>(s.size()),
                              nullptr, 0, nullptr, nullptr);
  std::string r(n, '\0');
  WideCharToMultiByte(CP_UTF8, 0, s.data(), static_cast<int>(s.size()),
                      r.data(), n, nullptr, nullptr);
  return r;
}
std::wstring moduleDir() {
  std::vector<wchar_t> b(32768);
  DWORD n = GetModuleFileNameW(nullptr, b.data(), static_cast<DWORD>(b.size()));
  std::wstring p(b.data(), n);
  return p.substr(0, p.find_last_of(L"\\/"));
}
void save() {
  WritePrivateProfileStringW(L"Preferencias", L"FPS",
                             std::to_wstring(fps).c_str(), iniPath.c_str());
  WritePrivateProfileStringW(L"Preferencias", L"AutoPausa",
                             policy.automatic ? L"1" : L"0", iniPath.c_str());
  WritePrivateProfileStringW(L"Preferencias", L"Volume",
                             std::to_wstring(volume).c_str(), iniPath.c_str());
  WritePrivateProfileStringW(L"Preferencias", L"Video", selected.c_str(),
                             iniPath.c_str());
}
void setupPreferences() {
  PWSTR p = nullptr;
  if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, KF_FLAG_CREATE,
                                     nullptr, &p))) {
    std::wstring d = std::wstring(p) + L"\\PapelVivo";
    CoTaskMemFree(p);
    CreateDirectoryW(d.c_str(), nullptr);
    iniPath = d + L"\\config.ini";
  } else
    iniPath = baseDir + L"\\config.ini";
  fps =
      GetPrivateProfileIntW(L"Preferencias", L"FPS", 30, iniPath.c_str()) == 60
          ? 60
          : 30;
  volume = std::clamp<int>(
      GetPrivateProfileIntW(L"Preferencias", L"Volume", 0, iniPath.c_str()), 0,
      100);
  policy.automatic = GetPrivateProfileIntW(L"Preferencias", L"AutoPausa", 1,
                                           iniPath.c_str()) != 0;
  std::vector<wchar_t> b(32768);
  GetPrivateProfileStringW(L"Preferencias", L"Video", L"", b.data(),
                           static_cast<DWORD>(b.size()), iniPath.c_str());
  selected = b.data();
  wchar_t language[16]{};
  GetPrivateProfileStringW(L"Preferencias", L"Idioma", L"pt-BR", language, 16,
                           iniPath.c_str());
  pvlang::english = wcscmp(language, L"en") == 0;
}
#include "panel.hpp"
void error(const std::wstring &s, bool dialog = true) {
  recordLog(L"ERRO", s);
  lastError = s;
  message = s.size() > 130 ? s.substr(0, 127) + L"..." : s;
  if (statusBox)
    SetWindowTextW(statusBox, s.c_str());
  if (dialog && !selftest) {
    MessageBoxW(window,
                (s + L"\n\nO registro real está em Diagnóstico. Você pode "
                     L"copiá-lo para relatar o erro.")
                    .c_str(),
                L"Papel Vivo — erro", MB_OK | MB_ICONWARNING);
    showLogs();
  }
}
void updateUi() {
  if (!window)
    return;
  auto textIfChanged = [](HWND c, const std::wstring &text) {
    int n = GetWindowTextLengthW(c);
    std::wstring old(n + 1, L'\0');
    GetWindowTextW(c, old.data(), n + 1);
    old.resize(n);
    const auto display = c == fileBox ? text : pvlang::text(text);
    if (old != display)
      SetWindowTextW(c, display.c_str());
  };
  textIfChanged(fileBox,
                selected.empty() ? L"Nenhum vídeo selecionado" : selected);
  textIfChanged(statusBox, message);
  textIfChanged(detailBox, renderInfo);
  textIfChanged(pauseButton, policy.manual ? L"Continuar" : L"Pausar");
  EnableWindow(pauseButton, playing);
  EnableWindow(GetDlgItem(window, ID_STOP), TRUE);
  EnableWindow(GetDlgItem(window, ID_CHOOSE), !media.busy());
  EnableWindow(GetDlgItem(window, ID_APPLY), !media.busy());
  EnableWindow(GetDlgItem(window, ID_PREVIEW), !media.busy());
  EnableWindow(GetDlgItem(window, ID_ALTERNATIVE), !media.busy());
  EnableWindow(GetDlgItem(window, ID_ORIGINAL), playing);
  static bool wasPlaying = false, wasPreview = false;
  if (wasPlaying != playing || wasPreview != preview) {
    RECT r{24, 334, 604, 510};
    InvalidateRect(window, &r, FALSE);
    wasPlaying = playing;
    wasPreview = preview;
  }
}
void reconcilePause() {
  bool hiddenPreview =
      preview && (!IsWindowVisible(window) || IsIconic(window));
  bool value = policy.paused() || hiddenPreview || converting;
  if (playing && value != lastPause) {
    player.pause(value);
    lastPause = value;
  }
  if (playing) {
    if (converting)
      message = L"Convertendo para 1080p/30. A interface continua ativa; Parar "
                L"encerra e cancela.";
    else if (policy.locked)
      message = L"Pausado: sessão bloqueada.";
    else if (policy.suspended || policy.displayOff)
      message = L"Pausado: tela desligada ou suspensão.";
    else if (policy.manual)
      message = L"Pausado por você. Use Continuar para retomar.";
    else if (policy.automatic && policy.fullscreen)
      message = L"Pausado automaticamente: aplicativo em tela cheia.";
    else if (hiddenPreview)
      message = L"Prévia pausada: janela oculta ou minimizada.";
    else
      message = preview
                    ? L"Pré-visualização em janela — ainda não é o wallpaper."
                : applicationPending
                    ? L"Preparando vídeo e verificando encaixe no desktop..."
                : alternative ? L"Seu Windows bloqueou. Usando modo de "
                                L"sobreposição (não interativo)."
                              : L"Aplicado atrás dos ícones.";
  }
  updateUi();
}
void removeVideo() {
  playing = false;
  player.stop();
  if (video && IsWindow(video))
    DestroyWindow(video);
  video = nullptr;
  if (worker && IsWindow(worker))
    RedrawWindow(worker, nullptr, nullptr,
                 RDW_INVALIDATE | RDW_ERASE | RDW_ALLCHILDREN);
  worker = nullptr;
  desktopTarget = {};
  preview = false;
  alternative = applicationPending = fileLoaded = false;
  lastPause = false;
  policy.manual = false;
  lastPresents = 0;
  actualFps = 0;
  message = L"Parado. O papel de parede estático do Windows está visível.";
  renderInfo = L"Nenhum vídeo sendo decodificado.";
  updateUi();
}
LRESULT CALLBACK VideoProc(HWND h, UINT m, WPARAM w, LPARAM l) {
  if (m == WM_SIZE) {
    player.resize(LOWORD(l), HIWORD(l));
    return 0;
  }
  if (m == WM_ERASEBKGND)
    return 1;
  if (m == WM_NCHITTEST)
    return HTTRANSPARENT;
  if (m == WM_MOUSEACTIVATE)
    return MA_NOACTIVATE;
  return DefWindowProcW(h, m, w, l);
}
bool validFile(const std::wstring &f) {
  DWORD a = GetFileAttributesW(f.c_str());
  if (a == INVALID_FILE_ATTRIBUTES || (a & FILE_ATTRIBUTE_DIRECTORY))
    return false;
  auto p = f.find_last_of(L'.');
  if (p == std::wstring::npos)
    return false;
  auto ext = f.substr(p);
  std::transform(ext.begin(), ext.end(), ext.begin(), ::towlower);
  return ext == L".mp4" || ext == L".webm" || ext == L".mkv" ||
         ext == L".avi" || ext == L".mov" || ext == L".m4v";
}
void startPlayback(bool asPreview, bool forceAlternative = false) {
  if (!validFile(selected)) {
    error(L"Escolha um arquivo local MP4, WebM, MKV, AVI ou MOV que exista no "
          L"disco.");
    return;
  }
  const bool manualBefore = policy.manual;
  DesktopTarget target =
      (asPreview || forceAlternative) ? DesktopTarget{} : findDesktopTarget();
  HWND destination = asPreview ? window : target.parent;
  const bool useAlternative = !asPreview && !destination;
  removeVideo();
  preview = asPreview;
  alternative = useAlternative;
  worker = (asPreview || useAlternative) ? nullptr : destination;
  desktopTarget = target;
  const bool layered =
      useAlternative || target.kind == DesktopTarget::RaisedProgman;
  RECT r = asPreview        ? RECT{24, 334, 604, 510}
           : useAlternative ? primaryMonitor()
                            : childMonitorRect(destination);
  DWORD ex = WS_EX_NOACTIVATE | (layered ? WS_EX_LAYERED : 0);
  DWORD style = WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
  if (useAlternative) {
    ex |= WS_EX_TOOLWINDOW | WS_EX_TRANSPARENT | WS_EX_LAYERED;
    style |= WS_POPUP;
  } else
    style |= WS_CHILD;
  video = CreateWindowExW(
      ex, layered ? L"PapelVivo.VideoLayered" : L"PapelVivo.Video", L"", style,
      r.left, r.top, r.right - r.left, r.bottom - r.top,
      useAlternative ? nullptr : destination, nullptr, instance, nullptr);
  if (!video) {
    error(L"Não foi possível criar a superfície de vídeo. Código Windows: " +
          std::to_wstring(GetLastError()));
    return;
  }
  if (!asPreview && !useAlternative && !bindWallpaper(video, desktopTarget)) {
    removeVideo();
    useOverlay(manualBefore);
    return;
  }
  if (useAlternative && !SetLayeredWindowAttributes(video, 0, 255, LWA_ALPHA)) {
    removeVideo();
    error(L"O Windows recusou o modo alternativo. Seu wallpaper original foi "
          L"preservado.");
    return;
  }
  ShowWindow(video, SW_SHOWNOACTIVATE);
  if (!asPreview && !useAlternative &&
      !attachedWallpaper(video, desktopTarget)) {
    removeVideo();
    useOverlay(manualBefore);
    return;
  }
  if (useAlternative && !sinkAlternative(video)) {
    removeVideo();
    error(L"Não foi possível posicionar o modo alternativo. O original foi "
          L"preservado.");
    return;
  }
  std::wstring e;
  if (!player.start(window, video, baseDir + L"\\libmpv-2.dll", fps, volume, e,
                    diagnosticSoftware)) {
    removeVideo();
    error(e);
    return;
  }
  playing = true;
  applicationPending = !asPreview;
  applicationStarted = GetTickCount64();
  fileLoaded = false;
  if (useAlternative && !selftest)
    MessageBoxW(window,
                L"Seu Windows bloqueou. Usando modo de sobreposição (não "
                L"interativo).\n\n"
                L"Este modo pode cobrir os ícones e não é o encaixe padrão. "
                L"Use Voltar ao "
                L"original para desfazer.",
                L"Papel Vivo — modo alternativo", MB_OK | MB_ICONINFORMATION);
  lastPause = !policy.paused();
  lastError.clear();
  player.load(toUtf8(selected));
  reconcilePause();
  save();
  lastTelemetry = GetTickCount64();
  lastPresents = 0;
  if (selftest)
    testStart = GetTickCount64();
}

void useOverlay(bool manual) {
  startPlayback(false, true);
  policy.manual = manual;
  reconcilePause();
}

bool sameStamp(const WIN32_FILE_ATTRIBUTE_DATA &a,
               const WIN32_FILE_ATTRIBUTE_DATA &b) {
  return a.nFileSizeHigh == b.nFileSizeHigh &&
         a.nFileSizeLow == b.nFileSizeLow &&
         CompareFileTime(&a.ftLastWriteTime, &b.ftLastWriteTime) == 0;
}
void cacheSize(const std::wstring &path, pv::VideoSize size) {
  checkedPath = path;
  checkedSize = size;
  GetFileAttributesExW(path.c_str(), GetFileExInfoStandard, &checkedStamp);
}
void dispatchReady(Intent intent) {
  if (intent == Intent::Select) {
    message = L"Vídeo verificado. Aplique no desktop ou pré-visualize.";
    updateUi();
  } else
    startPlayback(intent == Intent::Preview, intent == Intent::Alternative);
}
void requestVideo(Intent intent) {
  if (media.busy())
    return;
  if (!validFile(selected)) {
    error(L"Escolha um vídeo local válido antes de aplicar.");
    return;
  }
  WIN32_FILE_ATTRIBUTE_DATA stamp{};
  if (checkedPath == selected &&
      GetFileAttributesExW(selected.c_str(), GetFileExInfoStandard, &stamp) &&
      sameStamp(stamp, checkedStamp)) {
    dispatchReady(intent);
    return;
  }
  pendingIntent = intent;
  message = L"Verificando resolução antes de abrir o vídeo... Parar encerra o "
            L"aplicativo.";
  media.probe(window, baseDir + L"\\ferramentas", selected);
  updateUi();
}
void apply(bool asPreview) {
  requestVideo(asPreview ? Intent::Preview : Intent::Desktop);
}
void mediaFinished() {
  auto result = media.take();
  converting = false;
  reconcilePause();
  if (result.kind == MediaResult::Failed) {
    error(result.error);
    updateUi();
    return;
  }
  if (result.kind == MediaResult::Cancelled) {
    message = L"Operação cancelada. O original foi preservado.";
    updateUi();
    return;
  }
  if (result.kind == MediaResult::Probed && result.size.heavy()) {
    int answer = MessageBoxW(
        window,
        L"Esse vídeo é pesado. Quer converter pra 1080p (mais leve)?\n\nSim: "
        L"cria uma cópia "
        L"H.264/30 FPS e aplica. O original é preservado.\nNão: mantém o "
        L"original (pode "
        L"sobrecarregar seu PC).\nCancelar: não aplica este arquivo.",
        L"Papel Vivo — vídeo acima de 1920x1080",
        MB_YESNOCANCEL | MB_ICONQUESTION | MB_DEFBUTTON1);
    if (answer == IDCANCEL) {
      message = L"Aplicação cancelada; nada foi convertido.";
      updateUi();
      return;
    }
    if (answer == IDYES) {
      if (convertedFolder.empty()) {
        error(L"Não foi possível localizar a pasta local de conversões.");
        return;
      }
      converting = true;
      media.convert(window, baseDir + L"\\ferramentas", result.input,
                    convertedFolder);
      reconcilePause();
      message =
          L"Convertendo para 1080p/30. Parar encerra e cancela com segurança.";
      updateUi();
      return;
    }
  }
  // O resultado só é aceito para o arquivo que iniciou esta tarefa.
  if (result.input != selected)
    return;
  if (result.kind == MediaResult::Converted) {
    selected = result.output;
    if (pendingIntent == Intent::Select)
      pendingIntent = Intent::Desktop;
    save();
  }
  cacheSize(selected, result.size);
  dispatchReady(pendingIntent);
}
void choose() {
  if (media.busy())
    return;
  std::vector<wchar_t> b(32768);
  if (selected.size() < b.size())
    std::copy(selected.begin(), selected.end(), b.begin());
  OPENFILENAMEW f{sizeof(f)};
  f.hwndOwner = window;
  f.lpstrFile = b.data();
  f.nMaxFile = static_cast<DWORD>(b.size());
  f.lpstrFilter =
      pvlang::english
          ? L"Local videos\0*.mp4;*.m4v;*.webm;*.mkv;*.avi;*.mov\0All "
            L"files\0*.*\0\0"
          : L"Vídeos locais\0*.mp4;*.m4v;*.webm;*.mkv;*.avi;*.mov\0Todos os "
            L"arquivos\0*.*\0\0";
  f.lpstrTitle = pvlang::english ? L"Choose a video for Papel Vivo"
                                 : L"Escolher vídeo para o Papel Vivo";
  f.Flags =
      OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR | OFN_EXPLORER;
  if (GetOpenFileNameW(&f)) {
    selected = b.data();
    save();
    message = L"Vídeo selecionado. Aplique no desktop ou pré-visualize.";
    updateUi();
    requestVideo(Intent::Select);
  }
}
bool fullscreenActive() {
  HWND fg = GetForegroundWindow();
  if (!fg || fg == window || fg == video || fg == GetDesktopWindow() ||
      fg == GetShellWindow() || IsIconic(fg) || !IsWindowVisible(fg))
    return false;
  DWORD pid = 0;
  GetWindowThreadProcessId(fg, &pid);
  if (pid == GetCurrentProcessId())
    return false;
  wchar_t cls[128]{};
  GetClassNameW(fg, cls, 128);
  if (wcscmp(cls, L"Progman") == 0 || wcscmp(cls, L"WorkerW") == 0 ||
      wcscmp(cls, L"Shell_TrayWnd") == 0 ||
      wcscmp(cls, L"Shell_SecondaryTrayWnd") == 0)
    return false;
  DWORD cloaked = 0;
  DwmGetWindowAttribute(fg, DWMWA_CLOAKED, &cloaked, sizeof(cloaked));
  if (cloaked)
    return false;
  RECT r{};
  if (FAILED(DwmGetWindowAttribute(fg, DWMWA_EXTENDED_FRAME_BOUNDS, &r,
                                   sizeof(r))))
    if (!GetWindowRect(fg, &r))
      return false;
  MONITORINFO info{sizeof(info)};
  if (!GetMonitorInfoW(MonitorFromWindow(fg, MONITOR_DEFAULTTONEAREST), &info))
    return false;
  auto m = info.rcMonitor;
  return pv::covers({r.left, r.top, r.right, r.bottom},
                    {m.left, m.top, m.right, m.bottom});
}
void checkEnvironment() {
  policy.sample(fullscreenActive(), static_cast<int64_t>(GetTickCount64()));
  reconcilePause();
}
void CALLBACK focusEvent(HWINEVENTHOOK, DWORD, HWND, LONG, LONG, DWORD, DWORD) {
  if (window)
    PostMessageW(window, WM_CHECK, 0, 0);
}
void addTray() {
  tray.hWnd = window;
  tray.uID = 1;
  tray.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
  tray.uCallbackMessage = WM_TRAY;
  tray.hIcon = LoadIconW(instance, MAKEINTRESOURCEW(101));
  wcscpy_s(tray.szTip,
           pvlang::text(L"Papel Vivo — vídeo leve no desktop").c_str());
  trayAdded = Shell_NotifyIconW(NIM_ADD, &tray) != FALSE;
  tray.uVersion = NOTIFYICON_VERSION_4;
  if (trayAdded)
    Shell_NotifyIconW(NIM_SETVERSION, &tray);
}
void show() {
  ShowWindow(window, SW_RESTORE);
  SetForegroundWindow(window);
}
void menu() {
  HMENU m = CreatePopupMenu();
  AppendMenuW(m, MF_STRING, ID_SHOW, L"Abrir Papel Vivo");
  AppendMenuW(m, MF_STRING, ID_APPLY, L"Aplicar wallpaper");
  AppendMenuW(m, MF_STRING, ID_CHOOSE, L"Trocar vídeo...");
  AppendMenuW(m, MF_STRING | (playing ? 0 : MF_GRAYED), ID_PAUSE,
              policy.manual ? L"Continuar" : L"Pausar");
  AppendMenuW(m, MF_STRING, ID_STOP, L"Parar e encerrar");
  AppendMenuW(m, MF_STRING, ID_ALTERNATIVE, L"Modo alternativo");
  AppendMenuW(m, MF_STRING, ID_ORIGINAL, L"Voltar ao original");
  AppendMenuW(m, MF_SEPARATOR, 0, nullptr);
  AppendMenuW(m, MF_STRING, ID_SHOW, L"Configurações...");
  AppendMenuW(m, MF_STRING, ID_ABOUT, L"Sobre e desempenho");
  AppendMenuW(m, MF_STRING, ID_LOGS, L"Diagnóstico / copiar logs");
  AppendMenuW(m, MF_STRING, ID_FILES, L"Arquivos, README e licenças");
  AppendMenuW(m, MF_STRING, ID_LANGUAGE, L"Idioma");
  AppendMenuW(m, MF_STRING, ID_EXIT, L"Sair");
  POINT p;
  GetCursorPos(&p);
  SetForegroundWindow(window);
  int cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, p.x, p.y, 0,
                           window, nullptr);
  DestroyMenu(m);
  if (cmd)
    PostMessageW(window, WM_COMMAND, cmd, 0);
  PostMessageW(window, WM_NULL, 0, 0);
}
void telemetry() {
  if (!playing)
    return;
  const auto now = GetTickCount64();
  uint64_t count = player.presents();
  if (lastTelemetry && now > lastTelemetry)
    actualFps = static_cast<double>(count - lastPresents) * 1000 /
                (now - lastTelemetry);
  lastTelemetry = now;
  lastPresents = count;
  FILETIME create, exit, kernel, user, wall;
  GetSystemTimeAsFileTime(&wall);
  auto value = [](FILETIME t) {
    return (static_cast<unsigned long long>(t.dwHighDateTime) << 32) |
           t.dwLowDateTime;
  };
  if (GetProcessTimes(GetCurrentProcess(), &create, &exit, &kernel, &user)) {
    auto c = value(kernel) + value(user), t = value(wall);
    SYSTEM_INFO si{};
    GetSystemInfo(&si);
    if (lastWall && t > lastWall)
      cpu = 100.0 * (c - lastCpu) / (t - lastWall) /
            std::max<DWORD>(1, si.dwNumberOfProcessors);
    lastCpu = c;
    lastWall = t;
  }
  PROCESS_MEMORY_COUNTERS_EX mem{};
  mem.cb = sizeof(mem);
  GetProcessMemoryInfo(GetCurrentProcess(),
                       reinterpret_cast<PROCESS_MEMORY_COUNTERS *>(&mem),
                       sizeof(mem));
  auto hw = player.text("hwdec-current");
  std::wstring decode =
      (hw.empty() || hw == "no") ? L"por software" : L"aceleração de vídeo ativa";
  std::wostringstream text;
  text << L"Reprodução: " << decode << L"\r\n"
       << std::fixed << std::setprecision(1) << actualFps
       << L" FPS apresentados / teto " << fps << L"  |  CPU do processo: "
       << cpu << L"%\r\n"
       << L"RAM residente: " << mem.WorkingSetSize / 1048576.0
       << L" MB  |  Memória privada: ";
  if (mem.PrivateUsage)
    text << mem.PrivateUsage / 1048576.0 << L" MB";
  else
    text << L"indisponível";
  if (player.number("width") > 1920 || player.number("height") > 1080)
    text << L"\r\nVídeo acima de 1080p: prefira uma cópia H.264 1080p/30 para "
            L"reduzir carga.";
  renderInfo = text.str();
  updateUi();
}
HWND control(const wchar_t *cls, const wchar_t *text, DWORD style, int x, int y,
             int w, int h, int id = 0) {
  bool button = std::wstring(cls) == L"BUTTON" &&
                (style & BS_TYPEMASK) != BS_AUTOCHECKBOX;
  if (button)
    style = (style & ~BS_TYPEMASK) | BS_OWNERDRAW;
  HWND c = CreateWindowExW(
      0, cls, text, WS_CHILD | WS_VISIBLE | style, x, y, w, h, window,
      reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), instance, nullptr);
  SendMessageW(c, WM_SETFONT, reinterpret_cast<WPARAM>(normalFont), TRUE);
  if (button)
    SetWindowSubclass(c, ButtonMotion, 1, 0);
  if (std::wstring(cls) == L"BUTTON" && !button)
    SetWindowTheme(c, L"", L"");
  return c;
}
void initControls() {
  fileBox = control(L"EDIT", L"", ES_READONLY | ES_AUTOHSCROLL | WS_TABSTOP, 24,
                    228, 744, 28);
  control(L"BUTTON", L"Escolher vídeo...", WS_TABSTOP, 784, 216, 192, 44,
          ID_CHOOSE);
  control(L"BUTTON", L"Aplicar ao desktop", WS_TABSTOP, 24, 276, 216, 44,
          ID_APPLY);
  control(L"BUTTON", L"Pré-visualizar", WS_TABSTOP, 252, 276, 164, 44,
          ID_PREVIEW);
  control(L"BUTTON", L"Modo alternativo", WS_TABSTOP, 428, 276, 198, 44,
          ID_ALTERNATIVE);
  control(L"BUTTON", L"Diagnóstico", WS_TABSTOP, 638, 276, 166, 44, ID_LOGS);
  control(L"BUTTON", L"Sobre", WS_TABSTOP, 816, 276, 160, 44, ID_ABOUT);
  control(L"STATIC", L"Limite de apresentação", 0, 648, 350, 296, 24);
  fpsBox = control(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP, 648, 378,
                   140, 100, ID_FPS);
  SendMessageW(fpsBox, CB_ADDSTRING, 0, (LPARAM)L"30 FPS");
  SendMessageW(fpsBox, CB_ADDSTRING, 0, (LPARAM)L"60 FPS");
  SendMessageW(fpsBox, CB_SETCURSEL, fps == 60 ? 1 : 0, 0);
  autoBox = control(L"BUTTON", L"Pausar em tela cheia",
                    BS_AUTOCHECKBOX | WS_TABSTOP, 648, 416, 300, 32, ID_AUTO);
  SendMessageW(autoBox, BM_SETCHECK,
               policy.automatic ? BST_CHECKED : BST_UNCHECKED, 0);
  control(L"STATIC", L"Volume (0 = sem áudio)", 0, 648, 462, 300, 24);
  volumeBox = control(TRACKBAR_CLASSW, L"", TBS_AUTOTICKS | WS_TABSTOP, 640,
                      490, 320, 32, ID_VOLUME);
  SendMessageW(volumeBox, TBM_SETRANGE, TRUE, MAKELONG(0, 100));
  SendMessageW(volumeBox, TBM_SETPOS, TRUE, volume);
  pauseButton =
      control(L"BUTTON", L"Pausar", WS_TABSTOP, 24, 538, 160, 44, ID_PAUSE);
  control(L"BUTTON", L"Voltar ao original", WS_TABSTOP, 196, 538, 246, 44,
          ID_ORIGINAL);
  control(L"BUTTON", L"Parar e sair", WS_TABSTOP, 454, 538, 150, 44, ID_STOP);
  statusBox = control(L"STATIC", L"", SS_LEFT, 24, 604, 952, 40);
  detailBox = control(L"STATIC", L"", SS_LEFT, 24, 652, 952, 56);
  control(L"BUTTON",
          pvlang::english ? L"Idioma: English" : L"Idioma: Português (Brasil)",
          WS_TABSTOP, 648, 534, 304, 44, ID_LANGUAGE);
  updateUi();
}
void chooseLanguage() {
  HMENU m = CreatePopupMenu();
  AppendMenuW(m, MF_STRING | (!pvlang::english ? MF_CHECKED : 0), ID_PT,
              L"Português (Brasil)");
  AppendMenuW(m, MF_STRING | (pvlang::english ? MF_CHECKED : 0), ID_EN,
              L"English");
  RECT r{};
  GetWindowRect(GetDlgItem(window, ID_LANGUAGE), &r);
  SetForegroundWindow(window);
  int choice = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, r.left,
                              r.bottom, 0, window, nullptr);
  DestroyMenu(m);
  if (choice != ID_PT && choice != ID_EN)
    return;
  if ((choice == ID_EN) == pvlang::english)
    return;
  int answer = MessageBoxW(
      window,
      L"Para aplicar o idioma, é necessário reiniciar o "
      L"aplicativo.\n\nReiniciar agora? O wallpaper será interrompido; "
      L"reaplique-o depois de abrir.\n\nSim: reiniciar agora. Não: aplicar na "
      L"próxima abertura. Cancelar: não mudar.",
      L"Papel Vivo — idioma", MB_YESNOCANCEL | MB_ICONINFORMATION);
  if (answer == IDCANCEL)
    return;
  if (!WritePrivateProfileStringW(L"Preferencias", L"Idioma",
                                  choice == ID_EN ? L"en" : L"pt-BR",
                                  iniPath.c_str())) {
    error(L"Não foi possível salvar o idioma. Código Windows: " +
          std::to_wstring(GetLastError()));
    return;
  }
  recordLog(L"AÇÃO", choice == ID_EN ? L"Language scheduled: en"
                                     : L"Idioma agendado: pt-BR");
  if (answer == IDYES) {
    restartRequested = true;
    quitting = true;
    DestroyWindow(window);
  } else {
    message = L"Idioma salvo. Será aplicado na próxima abertura.";
    updateUi();
  }
}
void writeSelfTest() {
  testPassed = lastError.empty() && player.presents() > 20 && pauseMeasured &&
               pauseDrift <= 1 && player.presents() > resumeMark + 20;
  std::ofstream f(std::filesystem::path(baseDir + L"\\autoteste.json"));
  f << "{\n  \"ambiente\": \"exe Win32 real; registrar Wine/Windows no "
       "relatorio\",\n"
    << "  \"aprovado\": " << (testPassed ? "true" : "false") << ",\n"
    << "  \"frames\": " << player.presents() << ",\n"
    << "  \"frames_durante_pausa_estavel\": " << pauseDrift << ",\n"
    << "  \"frames_apos_retomada\": " << player.presents() - resumeMark << ",\n"
    << "  \"fps_apresentados\": " << actualFps << ",\n"
    << "  \"fullscreen_detectado\": " << (policy.fullscreen ? "true" : "false")
    << ",\n"
    << "  \"etapa_render\": " << player.stage() << ",\n"
    << "  \"espera_us\": " << player.waitDebug() << ",\n"
    << "  \"callbacks\": " << player.callbacks() << ",\n"
    << "  \"codec\": " << std::quoted(player.text("video-codec")) << ",\n"
    << "  \"vo\": " << std::quoted(player.text("current-vo")) << ",\n"
    << "  \"core_pause\": " << std::quoted(player.text("pause")) << ",\n"
    << "  \"decoder\": " << std::quoted(player.text("hwdec-current")) << ",\n"
    << "  \"posicao_video\": " << player.number("time-pos") << ",\n"
    << "  \"erro\": " << std::quoted(toUtf8(lastError)) << "\n}\n";
}

LRESULT CALLBACK WindowProc(HWND h, UINT m, WPARAM w, LPARAM l) {
  if (taskbarCreated && m == taskbarCreated) {
    addTray();
    lastRecover = 0;
    return 0;
  }
  switch (m) {
  case WM_CREATE:
    window = h;
    initControls();
    addTray();
    SetTimer(h, 1, 500, nullptr);
    SetTimer(h, 2, 1000, nullptr);
    return 0;
  case WM_DRAWITEM:
    drawButton(reinterpret_cast<DRAWITEMSTRUCT *>(l));
    return TRUE;
  case WM_CTLCOLOREDIT:
  case WM_CTLCOLORLISTBOX:
  case WM_CTLCOLORBTN:
  case WM_CTLCOLORSTATIC: {
    HDC dc = reinterpret_cast<HDC>(w);
    SetBkColor(dc, RGB(21, 17, 34));
    SetTextColor(dc, RGB(233, 226, 248));
    return reinterpret_cast<LRESULT>(bg);
  }
  case WM_ERASEBKGND:
    return 1;
  case WM_PAINT: {
    PAINTSTRUCT p;
    HDC dc = BeginPaint(h, &p);
    paintPanel(dc);
    EndPaint(h, &p);
    return 0;
  }
  case WM_COMMAND: {
    int id = LOWORD(w);
    if (HIWORD(w) == BN_CLICKED) {
      wchar_t caption[128]{};
      GetDlgItemTextW(h, id, caption, 128);
      recordLog(L"AÇÃO",
                std::wstring(caption) + L" (" + std::to_wstring(id) + L")");
    }
    switch (id) {
    case ID_CHOOSE:
      choose();
      break;
    case ID_APPLY:
      apply(false);
      break;
    case ID_PREVIEW:
      apply(true);
      break;
    case ID_PAUSE:
      if (playing) {
        policy.manual = !policy.manual;
        reconcilePause();
      }
      break;
    case ID_ALTERNATIVE:
      requestVideo(Intent::Alternative);
      break;
    case ID_STOP:
      // libmpv renderiza no MESMO processo: fecha o app, não apenas a janela.
      quitting = true;
      DestroyWindow(h);
      break;
    case ID_ORIGINAL:
      media.stop();
      converting = false;
      removeVideo();
      break;
    case ID_SHOW:
      show();
      break;
    case ID_EXIT:
      quitting = true;
      DestroyWindow(h);
      break;
    case ID_AUTO:
      policy.automatic =
          SendMessageW(autoBox, BM_GETCHECK, 0, 0) == BST_CHECKED;
      save();
      checkEnvironment();
      break;
    case ID_FPS:
      if (HIWORD(w) == CBN_SELCHANGE) {
        fps = SendMessageW(fpsBox, CB_GETCURSEL, 0, 0) == 1 ? 60 : 30;
        player.fps(fps);
        save();
      }
      break;
    case ID_LANGUAGE:
      chooseLanguage();
      break;
    case ID_FILES:
      ShellExecuteW(h, L"open", baseDir.c_str(), nullptr, nullptr, SW_SHOW);
      break;
    case ID_LOGS:
      showLogs();
      break;
    case ID_ABOUT:
      MessageBoxW(h, L"Papel Vivo 1.2.0 — kz\n\nEscolha um vídeo local e teste a prévia antes de aplicar ao desktop. Use Pausar/Continuar para controlar a reprodução e Voltar ao original para restaurar sua área de trabalho.\n\nO limite de 30/60 FPS e o desempenho dependem do vídeo e do computador. O modo alternativo pode cobrir os ícones.\n\nWindows 10/11 de 64 bits. Uso offline após o download. Consulte o guia do usuário e as licenças na pasta do aplicativo.", L"Sobre o Papel Vivo", MB_OK | MB_ICONINFORMATION);
      break;
    }
    return 0;
  }
  case WM_HSCROLL:
    if (reinterpret_cast<HWND>(l) == volumeBox) {
      volume = static_cast<int>(SendMessageW(volumeBox, TBM_GETPOS, 0, 0));
      player.volume(volume);
      save();
    }
    return 0;
  case WM_TRAY:
    if (LOWORD(l) == WM_CONTEXTMENU || LOWORD(l) == WM_RBUTTONUP)
      menu();
    else if (LOWORD(l) == NIN_SELECT || LOWORD(l) == WM_LBUTTONDBLCLK)
      show();
    return 0;
  case WM_CHECK:
    checkEnvironment();
    return 0;
  case WM_TIMER:
    if (w == 1) {
      checkEnvironment();
      if (playing && alternative)
        sinkAlternative(video);
      if (playing && !preview && !alternative &&
          !attachedWallpaper(video, desktopTarget) &&
          !positionWallpaper(video, desktopTarget))
        applicationPending = true; // nunca mantém sucesso se perdeu o encaixe
      if (playing && applicationPending) {
        const bool attached = alternative
                                  ? coversPrimary(video)
                                  : attachedWallpaper(video, desktopTarget);
        if (!attached) {
          if (!alternative) {
            useOverlay(policy.manual);
          } else {
            removeVideo();
            error(L"O modo alternativo não pôde ser exibido. Seu original foi "
                  L"preservado.",
                  false);
          }
        } else if (fileLoaded && player.presents() > loadedFrameMark) {
          applicationPending = false;
          reconcilePause();
        } else if (GetTickCount64() - applicationStarted > 10000) {
          removeVideo();
          error(L"O vídeo não começou a renderizar. Não foi confirmado como "
                L"aplicado.",
                false);
        }
      }
      if (playing && !preview && !alternative &&
          (!IsWindow(video) || !targetStillValid(desktopTarget)) &&
          GetTickCount64() - lastRecover > 5000) {
        lastRecover = GetTickCount64();
        if (findDesktopTarget()) {
          const bool manual = policy.manual;
          startPlayback(false);
          policy.manual = manual;
          reconcilePause();
        } else {
          removeVideo();
          error(L"O Explorer mudou. O vídeo foi parado com segurança; aplique "
                L"novamente quando o desktop estiver disponível.",
                false);
        }
      }
    }
    if (w == 2) {
      telemetry();
      if (selftest) {
        auto elapsed = GetTickCount64() - testStart;
        if (elapsed > 3000 && !testPaused) {
          policy.manual = true;
          reconcilePause();
          testPaused = true;
          pausedFrames = player.presents();
        }
        if (elapsed > 4000 && !pauseMeasured) {
          pauseStable = player.presents();
          pauseMeasured = true;
        }
        if (elapsed > 5000 && !testResumed) {
          pauseDrift = player.presents() - pauseStable;
          resumeMark = player.presents();
          policy.manual = false;
          reconcilePause();
          testResumed = true;
        }
        if (elapsed > 10000) {
          writeSelfTest();
          quitting = true;
          DestroyWindow(h);
        }
      }
    }
    return 0;
  case WM_PV_MEDIA:
    if (media.busy() && w == media.token())
      mediaFinished();
    return 0;
  case WM_PV_MPV: {
    bool failure = false;
    std::wstring why;
    player.events([&](const mpv_event &e) {
      if (e.event_id == MPV_EVENT_LOG_MESSAGE) {
        auto *log = static_cast<mpv_event_log_message *>(e.data);
        if (log && log->log_level <= MPV_LOG_LEVEL_WARN)
          recordLog(fromUtf8(log->level),
                    fromUtf8(std::string(log->prefix) + ": " + log->text));
      }

      if (e.event_id == MPV_EVENT_FILE_LOADED) {
        if (player.text("video-codec").empty()) {
          failure = true;
          why = L"Este arquivo não contém um vídeo compatível.";
        } else {
          lastError.clear();
          loadedFrameMark = player.presents();
          fileLoaded = true;
        }
      }
      if (e.event_id == MPV_EVENT_END_FILE) {
        auto *end = static_cast<mpv_event_end_file *>(e.data);
        if (end && end->reason == MPV_END_FILE_REASON_ERROR) {
          failure = true;
          why =
              L"Não foi possível reproduzir este vídeo. Ele pode estar "
              L"corrompido, sem codec suportado ou inacessível. Código mpv: " +
              std::to_wstring(end->error);
        }
      }
      if (e.event_id == MPV_EVENT_COMMAND_REPLY && e.error < 0) {
        failure = true;
        why = L"O mpv recusou abrir o arquivo selecionado. Código mpv: " +
              std::to_wstring(e.error);
      }
    });
    if (failure) {
      removeVideo();
      error(why);
    }
    return 0;
  }
  case WM_PV_RENDER_ERROR:
    removeVideo();
    error(
        L"O dispositivo gráfico foi perdido ou houve erro ao apresentar vídeo. "
        L"O original foi preservado. Atualize o driver e aplique novamente.");
    return 0;
  case WM_DISPLAYCHANGE:
    if (playing && !preview) {
      if (alternative)
        sinkAlternative(video);
      else
        positionWallpaper(video, desktopTarget);
    }
    return 0;
  case WM_WTSSESSION_CHANGE:
    if (w == WTS_SESSION_LOCK)
      policy.locked = true;
    else if (w == WTS_SESSION_UNLOCK)
      policy.locked = false;
    reconcilePause();
    return 0;
  case WM_POWERBROADCAST:
    if (w == PBT_APMSUSPEND)
      policy.suspended = true;
    else if (w == PBT_APMRESUMEAUTOMATIC || w == PBT_APMRESUMESUSPEND)
      policy.suspended = false;
    else if (w == PBT_POWERSETTINGCHANGE) {
      auto *p = reinterpret_cast<POWERBROADCAST_SETTING *>(l);
      if (IsEqualGUID(p->PowerSetting, GUID_CONSOLE_DISPLAY_STATE) &&
          p->DataLength == sizeof(DWORD)) {
        DWORD state = 0;
        CopyMemory(&state, p->Data, sizeof(state));
        policy.displayOff = state == 0;
      }
    }
    reconcilePause();
    return TRUE;
  case WM_QUERYENDSESSION:
    media.stop();
    converting = false;
    removeVideo();
    return TRUE;
  case WM_CLOSE:
    if (trayAdded && !selftest) {
      ShowWindow(h, SW_HIDE);
      return 0;
    }
    DestroyWindow(h);
    return 0;
  case WM_DESTROY:
    quitting = true;
    KillTimer(h, 1);
    KillTimer(h, 2);
    if (foregroundHook) {
      UnhookWinEvent(foregroundHook);
      foregroundHook = nullptr;
    }
    if (powerNotify)
      UnregisterPowerSettingNotification(powerNotify);
    WTSUnRegisterSessionNotification(h);
    media.stop();
    converting = false;
    removeVideo();
    if (trayAdded)
      Shell_NotifyIconW(NIM_DELETE, &tray);
    window = nullptr;
    PostQuitMessage(0);
    return 0;
  }
  return DefWindowProcW(h, m, w, l);
}
} // namespace
int WINAPI wWinMain(HINSTANCE in, HINSTANCE, PWSTR, int) {
  instance = in;
  SetDefaultDllDirectories(LOAD_LIBRARY_SEARCH_APPLICATION_DIR |
                           LOAD_LIBRARY_SEARCH_SYSTEM32);
  SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
  HANDLE singleton =
      CreateMutexW(nullptr, TRUE, L"Local\\PapelVivo.1.0.Singleton");
  if (!singleton || GetLastError() == ERROR_ALREADY_EXISTS) {
    HWND other = FindWindowW(L"PapelVivo.Controle", nullptr);
    if (other) {
      ShowWindow(other, SW_RESTORE);
      SetForegroundWindow(other);
    }
    if (singleton)
      CloseHandle(singleton);
    return 0;
  }
  SetPriorityClass(GetCurrentProcess(), BELOW_NORMAL_PRIORITY_CLASS);
  CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
  INITCOMMONCONTROLSEX cc{sizeof(cc), ICC_STANDARD_CLASSES | ICC_BAR_CLASSES};
  InitCommonControlsEx(&cc);
  baseDir = moduleDir();
  setupPreferences();
  setupLog();
  recordLog(L"INÍCIO", L"Papel Vivo 1.2.0 | kz | Win32 x64 | processo " +
                           std::to_wstring(GetCurrentProcessId()));
  if (selected.empty() ||
      GetFileAttributesW(selected.c_str()) == INVALID_FILE_ATTRIBUTES)
    selected = baseDir + L"\\assets\\Brisa-Azul.mp4";
  convertedFolder =
      iniPath.substr(0, iniPath.find_last_of(L"\\")) + L"\\Convertidos";
  int argc = 0;
  LPWSTR *argv = CommandLineToArgvW(GetCommandLineW(), &argc);
  bool previewArg = false;
  for (int i = 1; i < argc; i++) {
    if (wcscmp(argv[i], L"--sem-aceleracao") == 0)
      diagnosticSoftware = true;
    else if (wcscmp(argv[i], L"--visualizar") == 0)
      previewArg = true;
    else if (wcscmp(argv[i], L"--autoteste") == 0) {
      selftest = true;
      previewArg = true;
    } else if (i > 1)
      selected = argv[i];
  }
  LocalFree(argv);
  Gdiplus::GdiplusStartupInput gi;
  ULONG_PTR gdip = 0;
  Gdiplus::GdiplusStartup(&gdip, &gi, nullptr);
  initBanner();
  normalFont =
      CreateFontW(-16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                  OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                  DEFAULT_PITCH, L"Segoe UI");
  titleFont =
      CreateFontW(-28, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
                  DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                  CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
  bg = CreateSolidBrush(RGB(21, 17, 34));
  WNDCLASSEXW cls{sizeof(cls)};
  cls.hInstance = in;
  cls.hCursor = LoadCursorW(nullptr, IDC_ARROW);
  cls.hIcon = LoadIconW(instance, MAKEINTRESOURCEW(101));
  cls.hbrBackground = bg;
  cls.lpfnWndProc = WindowProc;
  cls.lpszClassName = L"PapelVivo.Controle";
  RegisterClassExW(&cls);
  cls.lpfnWndProc = VideoProc;
  cls.lpszClassName = L"PapelVivo.Video";
  cls.style = CS_OWNDC;
  RegisterClassExW(&cls);
  // WS_EX_LAYERED é incompatível com CS_OWNDC/CS_CLASSDC. O renderer mantém
  // seu GetDC válido até o fim; a classe layered não usa nenhum desses estilos.
  cls.lpszClassName = L"PapelVivo.VideoLayered";
  cls.style = 0;
  RegisterClassExW(&cls);
  RECT bounds{0, 0, 1000, 720};
  AdjustWindowRectEx(&bounds,
                     WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                     FALSE, 0);
  HWND h = CreateWindowExW(
      0, L"PapelVivo.Controle", L"Papel Vivo 1.2.0 — kz",
      WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX |
          WS_CLIPCHILDREN,
      CW_USEDEFAULT, CW_USEDEFAULT, bounds.right - bounds.left,
      bounds.bottom - bounds.top, nullptr, nullptr, in, nullptr);
  if (!h) {
    auto why = L"Não foi possível abrir o painel. Código Windows: " +
               std::to_wstring(GetLastError());
    recordLog(L"ERRO", why);
    MessageBoxW(
        nullptr,
        (why + L"\nCtrl+C copia esta mensagem. Logs: " + logPath).c_str(),
        L"Papel Vivo — erro", MB_OK | MB_ICONERROR);
    CloseHandle(singleton);
    return 1;
  }
  taskbarCreated = RegisterWindowMessageW(L"TaskbarCreated");
  foregroundHook = SetWinEventHook(
      EVENT_SYSTEM_FOREGROUND, EVENT_SYSTEM_FOREGROUND, nullptr, focusEvent, 0,
      0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
  WTSRegisterSessionNotification(h, NOTIFY_FOR_THIS_SESSION);
  powerNotify = RegisterPowerSettingNotification(h, &GUID_CONSOLE_DISPLAY_STATE,
                                                 DEVICE_NOTIFY_WINDOW_HANDLE);
  ShowWindow(h, SW_SHOW);
  UpdateWindow(h);
  if (previewArg && !selected.empty())
    apply(true);
  testStart = GetTickCount64();
  MSG msg;
  while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
    if (!IsDialogMessageW(h, &msg)) {
      TranslateMessage(&msg);
      DispatchMessageW(&msg);
    }
  }
  DeleteObject(normalFont);
  DeleteObject(titleFont);
  DeleteObject(bg);
  delete banner;
  if (bannerStream)
    bannerStream->Release();
  Gdiplus::GdiplusShutdown(gdip);
  CoUninitialize();
  CloseHandle(singleton);
  if (restartRequested) {
    std::vector<wchar_t> exe(32768);
    GetModuleFileNameW(nullptr, exe.data(), (DWORD)exe.size());
    std::wstring command = L"\"" + std::wstring(exe.data()) + L"\"";
    STARTUPINFOW si{sizeof(si)};
    PROCESS_INFORMATION pi{};
    if (CreateProcessW(exe.data(), command.data(), nullptr, nullptr, FALSE, 0,
                       nullptr, baseDir.c_str(), &si, &pi)) {
      CloseHandle(pi.hThread);
      CloseHandle(pi.hProcess);
    } else {
      auto why = L"Não foi possível reiniciar o aplicativo. Código Windows: " +
                 std::to_wstring(GetLastError());
      recordLog(L"ERRO", why);
      MessageBoxW(nullptr, why.c_str(), L"Papel Vivo — erro",
                  MB_OK | MB_ICONERROR);
    }
  }
  return selftest && !testPassed ? 2 : 0;
}
