#include "media_job.hpp"
#include <fstream>
#include <vector>
#include <objbase.h>

namespace {
struct Handle {
    HANDLE h = nullptr;
    ~Handle() {
        if (h && h != INVALID_HANDLE_VALUE)
            CloseHandle(h);
    }
    operator HANDLE() const { return h; }
};
struct ProcessResult {
    DWORD code = 1;
    bool cancelled = false;
    std::string text;
};
ProcessResult run(const std::wstring &exe, const std::vector<std::wstring> &args,
                  const std::atomic<bool> &cancel, DWORD timeout) {
    ProcessResult r;
    if (cancel) {
        r.cancelled = true;
        return r;
    }
    if (GetFileAttributesW(exe.c_str()) == INVALID_FILE_ATTRIBUTES) {
        r.text = "Ferramenta ausente. Execute Preparar-e-Abrir.cmd ou Preparar-Conversao.cmd.";
        return r;
    }
    Handle job{CreateJobObjectW(nullptr, nullptr)};
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
    limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    if (!job.h ||
        !SetInformationJobObject(job, JobObjectExtendedLimitInformation, &limits, sizeof(limits)))
        return r;
    SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
    Handle reader, writer;
    if (!CreatePipe(&reader.h, &writer.h, &sa, 0))
        return r;
    SetHandleInformation(reader, HANDLE_FLAG_INHERIT, 0);
    Handle input{CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, &sa,
                             OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr)};
    if (input.h == INVALID_HANDLE_VALUE)
        return r;
    std::wstring command = pv::quoteArg(exe);
    for (const auto &arg : args)
        command += L" " + pv::quoteArg(arg);
    STARTUPINFOW si{sizeof(si)};
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdOutput = writer;
    si.hStdError = writer;
    si.hStdInput = input;
    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(exe.c_str(), command.data(), nullptr, nullptr, TRUE,
                        CREATE_NO_WINDOW | CREATE_SUSPENDED | BELOW_NORMAL_PRIORITY_CLASS, nullptr,
                        nullptr, &si, &pi))
        return r;
    Handle process{pi.hProcess}, thread{pi.hThread};
    // Se a associação falhar, o filho ainda suspenso é encerrado. Nunca sobra órfão.
    if (!AssignProcessToJobObject(job, process)) {
        TerminateProcess(process, 1);
        WaitForSingleObject(process, INFINITE);
        return r;
    }
    CloseHandle(writer.h);
    writer.h = nullptr;
    if (ResumeThread(thread) == DWORD(-1)) {
        TerminateJobObject(job, 1);
        WaitForSingleObject(process, INFINITE);
        return r;
    }
    ULONGLONG started = GetTickCount64();
    auto drain = [&] {
        DWORD available = 0;
        for (int chunk = 0;
             chunk < 16 && PeekNamedPipe(reader, nullptr, 0, nullptr, &available, nullptr) &&
             available;
             ++chunk) {
            char data[4096];
            DWORD read = 0;
            if (!ReadFile(reader, data, (available < sizeof(data) ? available : sizeof(data)),
                          &read, nullptr) ||
                !read)
                break;
            r.text.append(data, read);
            if (r.text.size() > 65536)
                r.text.erase(0, r.text.size() - 65536);
        }
    };
    for (;;) {
        drain();
        if (WaitForSingleObject(process, 50) == WAIT_OBJECT_0)
            break;
        if (cancel || GetTickCount64() - started > timeout) {
            r.cancelled = cancel;
            TerminateJobObject(job, 1);
            WaitForSingleObject(process, INFINITE);
            if (!r.cancelled)
                r.text += "\nTempo limite excedido.";
            drain();
            return r;
        }
    }
    drain();
    GetExitCodeProcess(process, &r.code);
    return r;
}
std::wstring wide(const std::string &s) {
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), w.data(), n);
    return w;
}
ProcessResult probeFile(const std::wstring &tools, const std::wstring &input,
                        const std::atomic<bool> &cancel) {
    return run(tools + L"\\ffprobe.exe",
               {L"-v", L"error", L"-protocol_whitelist", L"file", L"-probesize", L"4M",
                L"-analyzeduration", L"2000000", L"-select_streams", L"v:0", L"-show_entries",
                L"stream=width,height", L"-of", L"csv=p=0:s=x", L"-i", input},
               cancel, 15000);
}
std::wstring failure(const ProcessResult &r) {
    return L"Código " + std::to_wstring(r.code) + L". " + wide(r.text.substr(0, 1200));
}
} // namespace
void MediaJob::probe(HWND owner, const std::wstring &tools, const std::wstring &input) {
    stop();
    cancel_ = false;
    busy_ = true;
    const auto token = ++serial_;
    thread_ = std::thread([=] {
        auto r = probeFile(tools, input, cancel_);
        result_ = {};
        result_.input = input;
        auto size = pv::dimensions(r.text);
        if (r.cancelled)
            result_.kind = MediaResult::Cancelled;
        else if (r.code == 0 && size) {
            result_.kind = MediaResult::Probed;
            result_.size = *size;
        } else
            result_.error =
                L"Não foi possível verificar a resolução antes de abrir o vídeo. " + failure(r);
        PostMessageW(owner, WM_PV_MEDIA, token, 0);
    });
}
void MediaJob::convert(HWND owner, const std::wstring &tools, const std::wstring &input,
                       const std::wstring &folder) {
    stop();
    cancel_ = false;
    busy_ = true;
    const auto token = ++serial_;
    thread_ = std::thread([=] {
        result_ = {};
        result_.input = input;
        GUID id{};
        wchar_t guid[40]{};
        if (FAILED(CoCreateGuid(&id))) {
            result_.error = L"Não foi possível criar o nome da cópia.";
            PostMessageW(owner, WM_PV_MEDIA, token, 0);
            return;
        }
        StringFromGUID2(id, guid, 40);
        auto final = folder + L"\\copia-leve-" + guid + L".mp4";
        auto partial = final + L".parcial.mp4";
        if (!CreateDirectoryW(folder.c_str(), nullptr) && GetLastError() != ERROR_ALREADY_EXISTS) {
            result_.error = L"Não foi possível criar a pasta Convertidos.";
            PostMessageW(owner, WM_PV_MEDIA, token, 0);
            return;
        }
        // -n e um GUID impedem sobrescrever qualquer arquivo. Sem shell, sem rede.
        // Dois threads de codec e um de filtro para não saturar o PC fraco.
        auto r = run(tools + L"\\ffmpeg.exe",
                     {L"-hide_banner",
                      L"-nostdin",
                      L"-n",
                      L"-loglevel",
                      L"error",
                      L"-protocol_whitelist",
                      L"file",
                      L"-threads",
                      L"2",
                      L"-i",
                      input,
                      L"-map",
                      L"0:v:0",
                      L"-filter_threads",
                      L"1",
                      L"-vf",
                      L"scale=w=1920:h=1080:force_original_aspect_ratio=decrease:force_divisible_"
                      L"by=2,fps=30",
                      L"-c:v",
                      L"libx264",
                      L"-threads",
                      L"2",
                      L"-preset",
                      L"veryfast",
                      L"-crf",
                      L"23",
                      L"-pix_fmt",
                      L"yuv420p",
                      L"-an",
                      L"-sn",
                      L"-dn",
                      L"-f",
                      L"mp4",
                      partial},
                     cancel_, 7200000);
        if (r.code == 0 && !r.cancelled && !cancel_) {
            auto verified = probeFile(tools, partial, cancel_);
            auto size = pv::dimensions(verified.text);
            if (verified.code == 0 && size && !size->heavy() && !cancel_ &&
                MoveFileExW(partial.c_str(), final.c_str(), MOVEFILE_WRITE_THROUGH)) {
                result_.kind = MediaResult::Converted;
                result_.output = final;
                result_.size = *size;
            } else
                result_.error = L"A cópia não passou na verificação ou não pôde ser salva. O "
                                L"original foi preservado.";
        } else if (cancel_ || r.cancelled)
            result_.kind = MediaResult::Cancelled;
        else
            result_.error = L"A conversão falhou; o original foi preservado. " + failure(r);
        DeleteFileW(partial.c_str());
        PostMessageW(owner, WM_PV_MEDIA, token, 0);
    });
}
MediaResult MediaJob::take() {
    if (thread_.joinable())
        thread_.join();
    busy_ = false;
    return std::move(result_);
}
void MediaJob::stop() {
    ++serial_;
    cancel_ = true;
    if (thread_.joinable())
        thread_.join();
    busy_ = false;
}
