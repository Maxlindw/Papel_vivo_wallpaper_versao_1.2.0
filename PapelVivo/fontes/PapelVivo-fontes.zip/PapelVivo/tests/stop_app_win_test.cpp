#include "workflow.hpp"
#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <string>
int checks = 0;
void check(bool ok, const char *s) {
    ++checks;
    if (!ok) {
        std::cerr << "FALHOU: " << s << '\n';
        ExitProcess(1);
    }
}
HWND find(DWORD pid, const wchar_t *cls) {
    struct Data {
        DWORD pid;
        const wchar_t *cls;
        HWND result;
    } data{pid, cls, nullptr};
    EnumWindows(
        [](HWND h, LPARAM l) -> BOOL {
            auto &d = *reinterpret_cast<Data *>(l);
            DWORD p = 0;
            wchar_t cls[128]{};
            GetWindowThreadProcessId(h, &p);
            GetClassNameW(h, cls, 128);
            if (p == d.pid && wcscmp(cls, d.cls) == 0) {
                d.result = h;
                return FALSE;
            }
            return TRUE;
        },
        reinterpret_cast<LPARAM>(&data));
    return data.result;
}
bool module(DWORD pid, const wchar_t *name) {
    HANDLE s = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid);
    if (s == INVALID_HANDLE_VALUE)
        return false;
    MODULEENTRY32W m{sizeof(m)};
    bool found = false;
    if (Module32FirstW(s, &m))
        do {
            if (_wcsicmp(m.szModule, name) == 0) {
                found = true;
                break;
            }
        } while (Module32NextW(s, &m));
    CloseHandle(s);
    return found;
}
DWORD child(DWORD pid) {
    HANDLE s = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (s == INVALID_HANDLE_VALUE)
        return 0;
    PROCESSENTRY32W p{sizeof(p)};
    DWORD found = 0;
    if (Process32FirstW(s, &p))
        do {
            if (p.th32ParentProcessID == pid && _wcsicmp(p.szExeFile, L"ffmpeg.exe") == 0) {
                found = p.th32ProcessID;
                break;
            }
        } while (Process32NextW(s, &p));
    CloseHandle(s);
    return found;
}
int wmain(int argc, wchar_t **argv) {
    check(argc == 4, "argumentos exe, video pequeno, video pesado");
    for (int mode = 0; mode < 4; ++mode) {
        std::cout << "Etapa UI " << mode << std::endl;
        std::wstring cmd = pv::quoteArg(argv[1]) + L" --visualizar " +
                           pv::quoteArg(argv[(mode == 1 || mode == 2) ? 3 : 2]);
        STARTUPINFOW si{sizeof(si)};
        PROCESS_INFORMATION p{};
        check(CreateProcessW(argv[1], cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si,
                             &p) != FALSE,
              "iniciar app real");
        CloseHandle(p.hThread);
        HWND main = nullptr;
        DWORD ffmpeg = 0;
        std::wstring converted;
        bool answered = false, ready = false, alternativeRequested = false;
        ULONGLONG deadline = GetTickCount64() + 60000;
        while (GetTickCount64() < deadline && WaitForSingleObject(p.hProcess, 0) == WAIT_TIMEOUT) {
            main = find(p.dwProcessId, L"PapelVivo.Controle");
            if (mode && !answered) {
                HWND question = find(p.dwProcessId, L"#32770");
                if (question) {
                    PostMessageW(question, WM_COMMAND, mode == 3 ? IDOK : IDYES, 0);
                    answered = true;
                }
            }
            if (mode == 1) {
                ffmpeg = child(p.dwProcessId);
                if (ffmpeg) {
                    ready = true;
                    break;
                }
            } else if (main && module(p.dwProcessId, L"libmpv-2.dll")) {
                if (mode == 3) {
                    if (!alternativeRequested) {
                        PostMessageW(main, WM_COMMAND, 112, 0);
                        alternativeRequested = true;
                    }
                    HWND surface = find(p.dwProcessId, L"PapelVivo.VideoLayered");
                    if (answered && surface && GetParent(surface) == nullptr &&
                        !(GetWindowLongPtrW(surface, GWL_EXSTYLE) & WS_EX_TOPMOST)) {
                        Sleep(1500);
                        ready = true;
                        break;
                    }
                } else if (mode == 2) {
                    HWND edit = FindWindowExW(main, nullptr, L"EDIT", nullptr);
                    wchar_t value[32768]{};
                    SendMessageTimeoutW(edit, WM_GETTEXT, 32768, reinterpret_cast<LPARAM>(value),
                                        SMTO_ABORTIFHUNG, 500, nullptr);
                    converted = value;
                    if (converted.find(L"copia-leve-") != std::wstring::npos &&
                        GetFileAttributesW(value) != INVALID_FILE_ATTRIBUTES) {
                        ready = true;
                        break;
                    }
                } else {
                    ready = true;
                    break;
                }
            }
            Sleep(10);
        }
        if (!ready) {
            TerminateProcess(p.hProcess, 1);
            WaitForSingleObject(p.hProcess, 5000);
        }
        check(ready, mode == 0 ? "player realmente carregou"
                     : mode == 1
                         ? "conversao realmente iniciou"
                         : "copia convertida selecionada e player carregado automaticamente");
        HANDLE encoder = ffmpeg ? OpenProcess(SYNCHRONIZE, FALSE, ffmpeg) : nullptr;
        PostMessageW(main, WM_COMMAND, 104, 0); // ID_STOP real da interface
        check(WaitForSingleObject(p.hProcess, 5000) == WAIT_OBJECT_0,
              "Parar termina o processo em ate 5s");
        DWORD exit = 1;
        GetExitCodeProcess(p.hProcess, &exit);
        check(exit == 0, "encerramento normal sem kill forcado");
        if (encoder) {
            check(WaitForSingleObject(encoder, 5000) == WAIT_OBJECT_0,
                  "Parar tambem encerra FFmpeg filho");
            CloseHandle(encoder);
        }
        CloseHandle(p.hProcess);
        if (!converted.empty())
            DeleteFileW(converted.c_str());
    }
    std::cout << checks << " verificacoes de Parar e fluxo da interface aprovadas\n";
    return 0;
}
