#include "desktop.hpp"
#include "media_job.hpp"
#include "player.hpp"
#include <iostream>
#include <string>
#include <vector>
int checks = 0;
void check(bool b, const char *name) {
    ++checks;
    if (!b) {
        std::cerr << "FALHOU: " << name << " erro Windows " << GetLastError() << '\n';
        ExitProcess(1);
    }
}
MediaResult wait(MediaJob &job) {
    ULONGLONG deadline = GetTickCount64() + 120000;
    MSG m{};
    while (GetTickCount64() < deadline) {
        while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) {
            if (m.message == WM_PV_MEDIA && m.wParam == job.token())
                return job.take();
            TranslateMessage(&m);
            DispatchMessageW(&m);
        }
        Sleep(10);
    }
    job.stop();
    check(false, "tarefa terminou em ate 120s");
    return {};
}
HWND make(const wchar_t *cls, HWND parent = nullptr) {
    RECT r = primaryMonitor();
    return CreateWindowExW(WS_EX_NOACTIVATE, cls, L"teste isolado",
                           WS_VISIBLE | (parent ? WS_CHILD : WS_POPUP), r.left, r.top,
                           r.right - r.left, r.bottom - r.top, parent, nullptr,
                           GetModuleHandleW(nullptr), nullptr);
}
int spawnAt = 0, spawnMessages = 0;
HWND spawned = nullptr;
LRESULT CALLBACK shellTestProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (m == 0x052C) {
        ++spawnMessages;
        if (spawnAt && spawnMessages == spawnAt) {
            spawned = make(L"WorkerW");
            SetWindowPos(spawned, h, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        }
        return 0;
    }
    return DefWindowProcW(h, m, w, l);
}
std::string utf8(const std::wstring &s) {
    int n = WideCharToMultiByte(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), nullptr, 0,
                                nullptr, nullptr);
    std::string out(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), out.data(), n, nullptr,
                        nullptr);
    return out;
}
int wmain(int argc, wchar_t **argv) {
    check(argc >= 4, "argumentos tools, video pequeno e pesado");
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    WNDCLASSW wc{};
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpfnWndProc = shellTestProc;
    for (const wchar_t *name :
         {L"PatchProgman", L"WorkerW", L"SHELLDLL_DefView", L"TestLayeredCanvas"}) {
        wc.lpszClassName = name;
        RegisterClassW(&wc);
    }
    wc.lpszClassName = L"TestOwnDCCanvas";
    wc.style = CS_OWNDC;
    RegisterClassW(&wc);
    HWND prog = make(L"PatchProgman"), icons = make(L"SHELLDLL_DefView", prog);
    HWND old = make(L"WorkerW"), bg = make(L"WorkerW", prog);
    SetWindowPos(old, prog, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    SetWindowPos(icons, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    auto classic = discoverDesktop(prog);
    check(classic.kind == DesktopTarget::ClassicWorker && classic.parent == old,
          "sem NOREDIRECTION usa WorkerW top-level");
    check(classic.parent != bg, "WorkerW filho nunca vira destino classico");
    HWND classicVideo = make(L"TestOwnDCCanvas", old);
    check(bindWallpaper(classicVideo, classic) && attachedWallpaper(classicVideo, classic),
          "metodo classico continua anexando sem layered");
    DestroyWindow(classicVideo);
    SetWindowLongPtrW(prog, GWL_EXSTYLE,
                      GetWindowLongPtrW(prog, GWL_EXSTYLE) | WS_EX_NOREDIRECTIONBITMAP);
    auto modern = discoverDesktop(prog);
    check(modern.kind == DesktopTarget::RaisedProgman && modern.parent == prog,
          "NOREDIRECTION escolhe Progman como pai");
    check(modern.parent != bg && modern.icons == icons,
          "nao enterra video dentro do WorkerW estatico");
    check(!targetStillValid(classic), "mudanca de topologia invalida destino antigo");
    RECT r = childMonitorRect(prog);
    HWND canvas = CreateWindowExW(WS_EX_LAYERED | WS_EX_NOACTIVATE, L"TestLayeredCanvas", L"",
                                  WS_CHILD, r.left, r.top, r.right - r.left, r.bottom - r.top, prog,
                                  nullptr, wc.hInstance, nullptr);
    check(canvas && bindWallpaper(canvas, modern), "layered WS_CHILD anexa a Progman");
    check(GetParent(canvas) == prog && !(GetWindowLongPtrW(canvas, GWL_STYLE) & WS_POPUP),
          "sem WS_POPUP no modo padrao");
    check(GetWindow(canvas, GW_HWNDPREV) == icons, "video imediatamente abaixo de DefView");
    check(beforeSibling(canvas, bg), "video acima do WorkerW estatico");
    check(attachedWallpaper(canvas, modern), "validacao inclui alpha 255 e ordem Z");
    SetLayeredWindowAttributes(canvas, 0, 100, LWA_ALPHA);
    check(!attachedWallpaper(canvas, modern), "alpha incorreto nao e sucesso");
    check(bindWallpaper(canvas, modern), "restaura alpha 255");
    SetWindowLongPtrW(canvas, GWL_STYLE, GetWindowLongPtrW(canvas, GWL_STYLE) | WS_POPUP);
    check(!bindWallpaper(canvas, modern), "rejeita CHILD e POPUP juntos");
    SetWindowLongPtrW(canvas, GWL_STYLE, GetWindowLongPtrW(canvas, GWL_STYLE) & ~WS_POPUP);
    check(bindWallpaper(canvas, modern), "restaura CHILD sem POPUP");
    HWND bad = CreateWindowExW(WS_EX_LAYERED, L"TestOwnDCCanvas", L"", WS_CHILD, 0, 0, 10, 10, prog,
                               nullptr, wc.hInstance, nullptr);
    check(!bad || !bindWallpaper(bad, modern), "classe OWNDC nao e aceita como layered");
    if (bad)
        DestroyWindow(bad);
    // Ordem Z perdida: reparo só move nossa janela, não o Explorer.
    SetWindowPos(canvas, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    check(!attachedWallpaper(canvas, modern), "nao marca como aplicado se Z estiver errado");
    check(positionWallpaper(canvas, modern) && attachedWallpaper(canvas, modern),
          "repara Z sem recriar player");
    SetWindowPos(bg, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    check(!positionWallpaper(canvas, modern), "detecta camada estatica acima do video");
    SetWindowPos(bg, canvas, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    check(bindWallpaper(canvas, modern), "volta a camada correta");
    if (argc > 5) {
        Player player;
        std::wstring message;
        check(player.start(prog, canvas, argv[5], 30, 0, message),
              "renderer inicia em layered SEM CS_OWNDC");
        player.load(utf8(argv[2]));
        auto pump = [&](unsigned millis) {
            ULONGLONG deadline = GetTickCount64() + millis;
            MSG m{};
            while (GetTickCount64() < deadline) {
                while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) {
                    TranslateMessage(&m);
                    DispatchMessageW(&m);
                }
                player.events([](const mpv_event &) {});
                Sleep(10);
            }
        };
        pump(3000);
        check(player.presents() > 10, "layered realmente renderizou frames");
        player.pause(true);
        pump(500);
        auto mark = player.presents();
        pump(500);
        check(player.presents() <= mark + 1, "pausa mantida na janela layered");
        player.pause(false);
        pump(1000);
        check(player.presents() > mark + 5, "retomada no layered");
        std::cout << "Frames layered: " << player.presents() << std::endl;
        player.stop();
        check(!player.active(), "libera renderer layered");
    }
    DestroyWindow(canvas);
    ShowWindow(icons, SW_HIDE);
    check(!discoverDesktop(prog), "sem icones nao confirma modo moderno");
    ShowWindow(icons, SW_SHOWNOACTIVATE);
    spawnMessages = 0;
    spawnAt = 0;
    check(findDesktopTarget(prog).parent == prog && spawnMessages == 1,
          "prepara composicao raised via 0x052C mesmo com HWNDs existentes");
    DestroyWindow(prog);
    DestroyWindow(old);
    prog = make(L"PatchProgman");
    icons = make(L"SHELLDLL_DefView", prog);
    spawnAt = 7;
    spawnMessages = 0;
    auto late = findDesktopTarget(prog);
    check(late.parent == spawned && spawnMessages == 7, "WorkerW pode surgir na setima tentativa");
    DestroyWindow(spawned);
    spawned = nullptr;
    spawnAt = 0;
    spawnMessages = 0;
    check(!findDesktopTarget(prog) && spawnMessages == 7,
          "limite de sete tentativas sem falso sucesso");
    DestroyWindow(prog);
    HWND owner = CreateWindowExW(0, L"STATIC", L"MediaJob test", 0, 0, 0, 1, 1, HWND_MESSAGE,
                                 nullptr, wc.hInstance, nullptr);
    MediaJob job;
    job.probe(owner, argv[1], argv[2]);
    auto small = wait(job);
    check(small.kind == MediaResult::Probed && !small.size.heavy(), "ffprobe real video pequeno");
    job.probe(owner, argv[1], argv[3]);
    auto heavy = wait(job);
    check(heavy.kind == MediaResult::Probed && heavy.size.width == 3584 &&
              heavy.size.height == 2016,
          "ffprobe real 3584x2016");
    wchar_t temp[MAX_PATH]{};
    GetTempPathW(MAX_PATH, temp);
    auto folder = std::wstring(temp) + L"PapelVivo-patch-test";
    job.convert(owner, argv[1], argv[3], folder);
    auto converted = wait(job);
    if (converted.kind != MediaResult::Converted)
        std::wcerr << converted.error << '\n';
    check(converted.kind == MediaResult::Converted && !converted.size.heavy(),
          "ffmpeg real gera copia <=1080p");
    check(converted.output != argv[3] && GetFileAttributesW(argv[3]) != INVALID_FILE_ATTRIBUTES,
          "original preservado");
    check(GetFileAttributesW(converted.output.c_str()) != INVALID_FILE_ATTRIBUTES,
          "copia publicada depois de verificar");
    if (argc > 4)
        check(CopyFileW(converted.output.c_str(), argv[4], FALSE) != FALSE,
              "copia preservada para verificar codec/FPS");
    DeleteFileW(converted.output.c_str());
    job.convert(owner, argv[1], argv[3], folder);
    Sleep(150);
    auto t = GetTickCount64();
    job.stop();
    check(!job.busy() && GetTickCount64() - t < 5000,
          "cancelamento encerra filho e aguarda em ate 5s");
    WIN32_FIND_DATAW found{};
    HANDLE search = FindFirstFileW((folder + L"\\*.parcial.mp4").c_str(), &found);
    check(search == INVALID_HANDLE_VALUE, "cancelamento limpa arquivos parciais");
    if (search != INVALID_HANDLE_VALUE)
        FindClose(search);
    DestroyWindow(owner);
    std::cout << checks << " verificacoes Win32 sinteticas e FFmpeg aprovadas\n";
    return 0;
}
