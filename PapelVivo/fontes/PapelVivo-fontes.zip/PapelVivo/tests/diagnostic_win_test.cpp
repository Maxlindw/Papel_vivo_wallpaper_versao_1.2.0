#include <windows.h>
#include <iostream>
#include <string>
HWND find(DWORD pid,const wchar_t* cls){struct D{DWORD p;const wchar_t*c;HWND h;}d{pid,cls,nullptr};EnumWindows([](HWND h,LPARAM l)->BOOL{auto&d=*(D*)l;DWORD p;GetWindowThreadProcessId(h,&p);wchar_t c[120];GetClassNameW(h,c,120);if(p==d.p&&!wcscmp(c,d.c)){d.h=h;return FALSE;}return TRUE;},(LPARAM)&d);return d.h;}
int wmain(int argc,wchar_t**argv){if(argc!=3)return 2;std::wstring cmd=L"\""+std::wstring(argv[1])+L"\" --visualizar \""+argv[2]+L"\"";STARTUPINFOW si{sizeof(si)};PROCESS_INFORMATION pi{};if(!CreateProcessW(argv[1],cmd.data(),nullptr,nullptr,FALSE,0,nullptr,nullptr,&si,&pi))return 3;CloseHandle(pi.hThread);
HWND logs=nullptr;ULONGLONG until=GetTickCount64()+20000;
while(GetTickCount64()<until){auto dialog=find(pi.dwProcessId,L"#32770");if(dialog)PostMessageW(dialog,WM_COMMAND,IDOK,0);logs=find(pi.dwProcessId,L"PapelVivo.Logs");if(logs)break;Sleep(50);}
if(!logs){TerminateProcess(pi.hProcess,1);std::cerr<<"Nao abriu diagnostico real\n";return 4;}
SendMessageW(logs,WM_COMMAND,601,0);Sleep(100);std::wstring copied;
if(OpenClipboard(nullptr)){HANDLE x=GetClipboardData(CF_UNICODETEXT);if(x){auto p=(const wchar_t*)GlobalLock(x);if(p){copied=p;GlobalUnlock(x);}}CloseClipboard();}
bool ok=copied.find(L"[ERRO]")!=std::wstring::npos&&copied.find(L"moov atom not found")!=std::wstring::npos&&copied.find(L"Papel Vivo 1.2.0")!=std::wstring::npos;
auto main=find(pi.dwProcessId,L"PapelVivo.Controle");PostMessageW(main,WM_COMMAND,104,0);bool stopped=WaitForSingleObject(pi.hProcess,5000)==WAIT_OBJECT_0;CloseHandle(pi.hProcess);
std::cout<<"Erro real de ffprobe no relatorio: "<<ok<<"; encerrou: "<<stopped<<"; caracteres copiados: "<<copied.size()<<"\n";return ok&&stopped?0:1;}
