# Papel Vivo 1.2.0 — kz

Local videos as desktop wallpaper for 64-bit Windows 10/11.
Text and documentation revision; the player was not rebuilt from scratch.

## Install and use
1. Run setup, select Português (Brasil) or English and read the terms.
2. Choose an application folder and shortcuts. Wait until progress completes.
3. Open Papel Vivo. Choose a local video or try Brisa Azul.
4. Use Preview before Apply to desktop. Check the result with Win+D.
5. Pause/Resume controls playback; Restore original releases the player.
6. Stop and exit closes the app and cancels an ongoing conversion. X may hide it in the tray.

The 30/60 FPS limit and volume are in the panel. Zero volume means silent playback.
Changing between Português (Brasil) and English takes effect after restart.
Large videos can be converted to a lighter copy without overwriting the original.
After downloading the complete package, setup and local playback work offline.

## Offline documentation
Open docs/Guide-en.pdf or docs/Guide-en.html.
Português: docs/Guia-pt-BR.pdf or docs/Guia-pt-BR.html.
HTML files contain their own images and do not use external services.

## Requirements and limitations
64-bit Windows 10/11. Prefer H.264 720p/1080p at 30 FPS on older computers.
Placement behind desktop icons depends on Windows and your driver. Alternative
mode may cover icons. FPS and resource use are not guaranteed. This revision
was tested under Wine/Linux, not physical Windows.

## Windows warning
SmartScreen or an unknown-publisher warning may appear. Check the download
source. If malware is detected, stop and investigate; do not disable protection
to run the file.

## Uninstall
Exit the app. Use Windows Apps → Papel Vivo → Uninstall, or the Uninstall shortcut.
Original videos, preferences, logs and unrelated files are preserved.
User data is stored in %LOCALAPPDATA%\PapelVivo.

## Licenses and sources
Third-party library sources are available through the official links listed in [LICENCAS-TERCEIROS.md](LICENCAS-TERCEIROS.md) (English notice: [THIRD-PARTY-LICENSES.md](THIRD-PARTY-LICENSES.md)).

Full license texts and main source archives are included.
Official links alone do not establish that all corresponding sources required for the distributed binaries are available; that verification remains pending.

## Final validation
Final validation on physical Windows is the author’s responsibility. The app was tested under Wine/Linux and passed playback, pause, resume, FPS, volume and uninstall tests.

Free of charge, with optional contributions on the project page. No donation is required to use it.
