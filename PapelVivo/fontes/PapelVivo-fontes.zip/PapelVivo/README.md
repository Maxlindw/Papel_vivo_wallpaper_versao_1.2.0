# Papel Vivo 1.2.0 — kz

Vídeos locais como papel de parede no Windows 10/11 de 64 bits.
Revisão de textos e documentação, sem refazer o player.

## Instalar e usar
1. Abra o instalador, escolha Português (Brasil) ou English e leia os termos.
2. Escolha uma pasta própria e os atalhos. Aguarde a barra de progresso concluir.
3. Abra Papel Vivo. Escolha um vídeo local ou teste Brisa Azul.
4. Use Pré-visualizar antes de Aplicar ao desktop. Confira com Win+D.
5. Pausar/Continuar controla a reprodução; Voltar ao original libera o player.
6. Parar e sair encerra o app e uma conversão em andamento. X pode ocultar na bandeja.

O limite 30/60 FPS e o volume ficam no painel. Volume zero é sem áudio.
A troca entre Português (Brasil) e English é aplicada após reiniciar.
Vídeos maiores podem ser convertidos em cópia mais leve, sem sobrescrever o original.
Depois de baixar o pacote completo, instalação e reprodução local funcionam offline.

## Documentação offline
Abra docs/Guia-pt-BR.pdf ou docs/Guia-pt-BR.html.
English: docs/Guide-en.pdf ou docs/Guide-en.html.
O HTML contém as próprias imagens e não usa serviços externos.

## Requisitos e limites
Windows 10/11 x64. Prefira H.264 720p/1080p a 30 FPS em computadores antigos.
O resultado atrás dos ícones depende do Windows e do driver. O modo alternativo
pode cobrir ícones. Não há promessa de FPS ou consumo fixo. Os testes desta
revisão foram feitos em Wine/Linux, não em Windows físico.

## Aviso do Windows
O SmartScreen ou outro aviso de editor desconhecido pode aparecer. Confirme a
origem do download. Se houver detecção de malware, interrompa e investigue;
não desative proteções para executar o arquivo.

## Desinstalar
Saia pelo app. Use Aplicativos do Windows → Papel Vivo → Desinstalar, ou o
atalho Desinstalar. Vídeos originais, preferências, logs e arquivos extras são preservados.
Os dados do usuário ficam em %LOCALAPPDATA%\PapelVivo.

## Licenças e fontes
Os fontes das bibliotecas de terceiros estão disponíveis nos links oficiais listados em [LICENCAS-TERCEIROS.md](LICENCAS-TERCEIROS.md).

Textos completos das licenças e fontes principais acompanham o pacote.
Os links oficiais não comprovam, por si só, a disponibilidade de todos os fontes correspondentes exigidos para os binários distribuídos; essa verificação permanece pendente.

## Validação final
A validação final em Windows físico é responsabilidade do autor. O app foi testado em Wine/Linux e passou nos testes de reprodução, pausa, retomada, FPS, volume e desinstalação.

Gratuito, com contribuição opcional na página do projeto. Não é necessário doar para usar.
