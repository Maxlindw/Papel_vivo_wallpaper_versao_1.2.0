// Componente novo: licença própria em LICENCA-PAPEL-VIVO.txt; exceções LGPL
// preservadas. Painel Win32: arte incorporada, animação breve sob demanda e
// diagnóstico local.
Gdiplus::Bitmap *banner = nullptr;
IStream *bannerStream = nullptr;
std::wstring logPath, logText;
HWND logWindow = nullptr, logEdit = nullptr;
void setupLog() {
  auto dir = std::filesystem::path(iniPath).parent_path() / L"Logs";
  std::error_code ec;
  std::filesystem::create_directories(dir, ec);
  logPath = (dir / L"PapelVivo.log").wstring();
  if (std::filesystem::file_size(logPath, ec) > 1024 * 1024 && !ec) {
    std::filesystem::remove(dir / L"PapelVivo-anterior.log", ec);
    std::filesystem::rename(logPath, dir / L"PapelVivo-anterior.log", ec);
  }
  std::ifstream in{std::filesystem::path(logPath)};
  logText = fromUtf8(std::string(std::istreambuf_iterator<char>(in), {}));
  if (logText.size() > 180000)
    logText = logText.substr(logText.size() - 180000);
}
void recordLog(const std::wstring &level, const std::wstring &text) {
  SYSTEMTIME t;
  GetLocalTime(&t);
  wchar_t date[80];
  swprintf(date, 80, L"%04u-%02u-%02u %02u:%02u:%02u.%03u", t.wYear, t.wMonth,
           t.wDay, t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
  std::wstring line = std::wstring(date) + L" [" + pvlang::text(level) + L"] " +
                      pvlang::text(text) + L"\r\n";
  logText += line;
  if (logText.size() > 180000)
    logText.erase(0, logText.size() - 180000);
  std::error_code ec;
  auto size = std::filesystem::file_size(logPath, ec);
  if (!ec && size > 2 * 1024 * 1024) {
    auto old = std::filesystem::path(logPath).parent_path() /
               L"PapelVivo-anterior.log";
    std::filesystem::remove(old, ec);
    std::filesystem::rename(logPath, old, ec);
  }
  std::ofstream f(std::filesystem::path(logPath),
                  std::ios::app | std::ios::binary);
  f << toUtf8(line);
  if (logEdit) {
    SetWindowTextW(logEdit, logText.c_str());
    SendMessageW(logEdit, EM_SETSEL, logText.size(), logText.size());
    SendMessageW(logEdit, EM_SCROLLCARET, 0, 0);
  }
}
LRESULT CALLBACK LogProc(HWND h, UINT m, WPARAM w, LPARAM l) {
  if (m == WM_CREATE) {
    logEdit =
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", logText.c_str(),
                        WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL |
                            ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
                        16, 48, 768, 420, h, (HMENU)600, instance, nullptr);
    SendMessageW(logEdit, EM_SETLIMITTEXT, 250000, 0);
    SendMessageW(logEdit, WM_SETFONT, (WPARAM)normalFont, TRUE);
    HWND label = CreateWindowW(L"STATIC",
                               L"Registros reais do aparelho. Revise caminhos "
                               L"pessoais antes de compartilhar.",
                               WS_CHILD | WS_VISIBLE, 16, 16, 768, 24, h,
                               nullptr, instance, nullptr);
    SendMessageW(label, WM_SETFONT, (WPARAM)normalFont, TRUE);
    const wchar_t *names[] = {L"Copiar relatório", L"Abrir pasta de logs",
                              L"Fechar"};
    for (int i = 0; i < 3; i++) {
      HWND b = CreateWindowW(
          L"BUTTON", names[i], WS_CHILD | WS_VISIBLE | WS_TABSTOP, 16 + i * 256,
          484, 240, 44, h, (HMENU)(INT_PTR)(601 + i), instance, nullptr);
      SendMessageW(b, WM_SETFONT, (WPARAM)normalFont, TRUE);
    }
    return 0;
  }
  if (m == WM_COMMAND) {
    if (LOWORD(w) == 601) {
      const std::wstring report = L"Papel Vivo 1.2.0 | autor kz\r\n" +
                                  renderInfo + L"\r\n\r\n" + logText;
      HGLOBAL data =
          GlobalAlloc(GMEM_MOVEABLE, (report.size() + 1) * sizeof(wchar_t));
      if (data) {
        void *p = GlobalLock(data);
        if (p) {
          memcpy(p, report.c_str(), (report.size() + 1) * sizeof(wchar_t));
          GlobalUnlock(data);
          if (OpenClipboard(h)) {
            EmptyClipboard();
            if (SetClipboardData(CF_UNICODETEXT, data))
              data = nullptr;
            CloseClipboard();
          }
        }
        if (data)
          GlobalFree(data);
      }
    } else if (LOWORD(w) == 602) {
      auto dir = std::filesystem::path(logPath).parent_path().wstring();
      ShellExecuteW(h, L"open", dir.c_str(), nullptr, nullptr, SW_SHOW);
    } else if (LOWORD(w) == 603)
      DestroyWindow(h);
    return 0;
  }
  if (m == WM_DESTROY) {
    logEdit = nullptr;
    logWindow = nullptr;
    return 0;
  }
  return DefWindowProcW(h, m, w, l);
}
void showLogs() {
  if (logWindow) {
    ShowWindow(logWindow, SW_RESTORE);
    SetForegroundWindow(logWindow);
    return;
  }
  WNDCLASSW c{};
  c.lpfnWndProc = LogProc;
  c.hInstance = instance;
  c.lpszClassName = L"PapelVivo.Logs";
  c.hCursor = LoadCursorW(nullptr, IDC_ARROW);
  c.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
  c.hIcon = LoadIconW(instance, MAKEINTRESOURCEW(101));
  RegisterClassW(&c);
  RECT r{0, 0, 800, 544};
  AdjustWindowRect(&r, WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU, FALSE);
  logWindow =
      CreateWindowW(c.lpszClassName, L"Papel Vivo — diagnóstico copiável",
                    WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
                    CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left,
                    r.bottom - r.top, window, nullptr, instance, nullptr);
}
void initBanner() {
  HRSRC res = FindResourceW(instance, MAKEINTRESOURCEW(102), RT_RCDATA);
  if (!res)
    return;
  DWORD size = SizeofResource(instance, res);
  HGLOBAL mem = GlobalAlloc(GMEM_MOVEABLE, size);
  if (!mem)
    return;
  void *dest = GlobalLock(mem);
  memcpy(dest, LockResource(LoadResource(instance, res)), size);
  GlobalUnlock(mem);
  IStream *stream = nullptr;
  if (SUCCEEDED(CreateStreamOnHGlobal(mem, TRUE, &stream))) {
    banner = Gdiplus::Bitmap::FromStream(stream);
    bannerStream = stream;
  } else
    GlobalFree(mem);
}
LRESULT CALLBACK ButtonMotion(HWND h, UINT m, WPARAM w, LPARAM l, UINT_PTR,
                              DWORD_PTR) {
  if (m == WM_MOUSEMOVE && !GetPropW(h, L"hot")) {
    SetPropW(h, L"hot", (HANDLE)1);
    TRACKMOUSEEVENT t{sizeof(t), TME_LEAVE, h, 0};
    TrackMouseEvent(&t);
    BOOL anim = TRUE;
    SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION, 0, &anim, 0);
    if (anim)
      SetTimer(h, 88, 20, nullptr);
    else {
      SetPropW(h, L"fade", (HANDLE)100);
      InvalidateRect(h, nullptr, FALSE);
    }
  }
  if (m == WM_MOUSELEAVE) {
    RemovePropW(h, L"hot");
    BOOL anim = TRUE;
    SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION, 0, &anim, 0);
    if (anim)
      SetTimer(h, 88, 20, nullptr);
    else {
      RemovePropW(h, L"fade");
      InvalidateRect(h, nullptr, FALSE);
    }
  }
  if (m == WM_TIMER && w == 88) {
    int a = (int)(INT_PTR)GetPropW(h, L"fade"),
        target = GetPropW(h, L"hot") ? 100 : 0;
    a = target > a ? std::min(target, a + 20) : std::max(target, a - 20);
    SetPropW(h, L"fade", (HANDLE)(INT_PTR)a);
    InvalidateRect(h, nullptr, FALSE);
    if (a == target)
      KillTimer(h, 88);
    return 0;
  }
  if (m == WM_NCDESTROY) {
    KillTimer(h, 88);
    RemovePropW(h, L"fade");
    RemovePropW(h, L"hot");
    RemoveWindowSubclass(h, ButtonMotion, 1);
  }
  return DefSubclassProc(h, m, w, l);
}
void drawButton(DRAWITEMSTRUCT *d) {
  RECT r = d->rcItem;
  bool primary = d->CtlID == ID_APPLY, disabled = d->itemState & ODS_DISABLED;
  int a = (int)(INT_PTR)GetPropW(d->hwndItem, L"fade");
  using namespace Gdiplus;
  HBRUSH canvas = CreateSolidBrush(d->CtlID == ID_LANGUAGE ? RGB(26, 21, 40)
                                                           : RGB(21, 17, 34));
  FillRect(d->hDC, &r, canvas);
  DeleteObject(canvas);
  Graphics g(d->hDC);
  g.SetSmoothingMode(SmoothingModeAntiAlias);
  GraphicsPath shape;
  float x = .5f, y = .5f, w = (float)r.right - 1, h = (float)r.bottom - 1,
        rad = 14;
  shape.AddArc(x, y, rad, rad, 180, 90);
  shape.AddArc(x + w - rad, y, rad, rad, 270, 90);
  shape.AddArc(x + w - rad, y + h - rad, rad, rad, 0, 90);
  shape.AddArc(x, y + h - rad, rad, rad, 90, 90);
  shape.CloseFigure();
  Color top = primary ? Color(255, 126 + a / 25, 73 + a / 25, 232 + a / 25)
                      : Color(255, 47 + a / 10, 38 + a / 12, 65 + a / 10);
  Color bottom = primary ? Color(255, 96 + a / 25, 43 + a / 25, 195 + a / 25)
                         : Color(255, 32 + a / 10, 25 + a / 12, 47 + a / 10);
  if (disabled) {
    top = Color(255, 35, 29, 45);
    bottom = Color(255, 28, 23, 37);
  }
  if (d->itemState & ODS_SELECTED) {
    top = Color(255, 74, 40, 124);
    bottom = Color(255, 62, 31, 109);
  }
  LinearGradientBrush fill(Point(0, 0), Point(0, r.bottom), top, bottom);
  g.FillPath(&fill, &shape);
  Pen border(primary ? Color(255, 193, 162, 255) : Color(255, 150, 126, 182),
             1.0f);
  g.DrawPath(&border, &shape);
  wchar_t text[128];
  GetWindowTextW(d->hwndItem, text, 128);
  SelectObject(d->hDC, normalFont);
  SetBkMode(d->hDC, TRANSPARENT);
  SetTextColor(d->hDC, disabled ? RGB(134, 124, 150) : RGB(249, 245, 255));
  DrawTextW(d->hDC, text, -1, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
  if (d->itemState & ODS_FOCUS) {
    InflateRect(&r, -4, -4);
    DrawFocusRect(d->hDC, &r);
  }
}
void paintPanel(HDC dc) {
  using namespace Gdiplus;
  RECT client{0, 0, 1000, 720};
  FillRect(dc, &client, bg);
  Graphics g(dc);
  g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
  SolidBrush base(Color(255, 20, 9, 40));
  g.FillRectangle(&base, 0, 0, 1000, 180);
  g.SetClip(Rect(0, 0, 1000, 180));
  if (banner)
    g.DrawImage(banner, Rect(480, 0, 520, 290));
  LinearGradientBrush fade(Point(480, 0), Point(700, 0), Color(255, 20, 9, 40),
                           Color(0, 20, 9, 40));
  g.FillRectangle(&fade, 480, 0, 220, 180);
  SolidBrush ink(Color(255, 244, 237, 255)), muted(Color(255, 198, 180, 219)),
      accent(Color(255, 202, 163, 255));
  HFONT hero =
      CreateFontW(-44, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                  OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                  DEFAULT_PITCH, L"Segoe UI");
  HGDIOBJ old = SelectObject(dc, normalFont);
  SetBkMode(dc, TRANSPARENT);
  SetTextColor(dc, RGB(202, 163, 255));
  RECT eyebrow{32, 20, 530, 44};
  DrawTextW(dc, L"KZ  /  PAPEL VIVO 1.2.0", -1, &eyebrow, DT_SINGLELINE);
  SelectObject(dc, hero);
  SetTextColor(dc, RGB(244, 237, 255));
  RECT heading{28, 52, 600, 110};
  DrawTextW(dc, L"Seu desktop, vivo.", -1, &heading, DT_SINGLELINE);
  SelectObject(dc, normalFont);
  SetTextColor(dc, RGB(198, 180, 219));
  RECT sub{32, 120, 550, 170};
  DrawTextW(dc,
            L"Vídeos locais. Sem navegador embutido.\nO papel de parede "
            L"original fica intacto.",
            -1, &sub, DT_LEFT);
  SelectObject(dc, old);
  DeleteObject(hero);
  g.ResetClip();
  SolidBrush surface(Color(255, 26, 21, 40));
  g.FillRectangle(&surface, 628, 334, 348, 248);
  SelectObject(dc, normalFont);
  SetBkMode(dc, TRANSPARENT);
  SetTextColor(dc, RGB(186, 170, 207));
  RECT label{24, 196, 760, 218};
  DrawTextW(dc, L"SEU VÍDEO  /  MP4 · WEBM · MKV · AVI · MOV", -1, &label,
            DT_SINGLELINE);
  if (!preview || !playing) {
    RECT r{24, 334, 604, 510};
    HBRUSH b = CreateSolidBrush(RGB(26, 21, 40));
    FillRect(dc, &r, b);
    DeleteObject(b);
    SetTextColor(dc, RGB(227, 214, 246));
    RECT t{48, 372, 578, 490};
    DrawTextW(
        dc,
        playing ? L"Aplicado no desktop.\nMinimize as janelas (Win+D) para ver."
                : L"Pronto para dar vida à sua tela.\n\nEscolha um vídeo ou "
                  L"teste a "
                  L"Brisa Azul incluída.",
        -1, &t, DT_LEFT | DT_WORDBREAK);
  }
}
