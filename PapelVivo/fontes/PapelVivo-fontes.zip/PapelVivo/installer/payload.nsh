; Lista explícita, gerada após revisão do staging.
!macro ExtractPayload
 SetOutPath "$NewDir"
 ClearErrors
 File "/oname=LICENCA-PAPEL-VIVO.txt" "${PAYLOAD_ROOT}\LICENCA-PAPEL-VIVO.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\LICENCA-PAPEL-VIVO.txt" 0 install_fail
 Push "$(ExtractedText) LICENCA-PAPEL-VIVO.txt"
 Call Log
 SetOutPath "$NewDir"
 ClearErrors
 File "/oname=LICENCAS-TERCEIROS.md" "${PAYLOAD_ROOT}\LICENCAS-TERCEIROS.md"
 IfErrors install_fail
 IfFileExists "$NewDir\LICENCAS-TERCEIROS.md" 0 install_fail
 Push "$(ExtractedText) LICENCAS-TERCEIROS.md"
 Call Log
 SetOutPath "$NewDir"
 ClearErrors
 File "/oname=LICENSE-PAPEL-VIVO-en.txt" "${PAYLOAD_ROOT}\LICENSE-PAPEL-VIVO-en.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\LICENSE-PAPEL-VIVO-en.txt" 0 install_fail
 Push "$(ExtractedText) LICENSE-PAPEL-VIVO-en.txt"
 Call Log
 SetOutPath "$NewDir"
 ClearErrors
 File "/oname=PapelVivo.exe" "${PAYLOAD_ROOT}\PapelVivo.exe"
 IfErrors install_fail
 IfFileExists "$NewDir\PapelVivo.exe" 0 install_fail
 Push "$(ExtractedText) PapelVivo.exe"
 Call Log
 SetOutPath "$NewDir"
 ClearErrors
 File "/oname=README-en.md" "${PAYLOAD_ROOT}\README-en.md"
 IfErrors install_fail
 IfFileExists "$NewDir\README-en.md" 0 install_fail
 Push "$(ExtractedText) README-en.md"
 Call Log
 SetOutPath "$NewDir"
 ClearErrors
 File "/oname=README.md" "${PAYLOAD_ROOT}\README.md"
 IfErrors install_fail
 IfFileExists "$NewDir\README.md" 0 install_fail
 Push "$(ExtractedText) README.md"
 Call Log
 SetOutPath "$NewDir"
 ClearErrors
 File "/oname=THIRD-PARTY-LICENSES.md" "${PAYLOAD_ROOT}\THIRD-PARTY-LICENSES.md"
 IfErrors install_fail
 IfFileExists "$NewDir\THIRD-PARTY-LICENSES.md" 0 install_fail
 Push "$(ExtractedText) THIRD-PARTY-LICENSES.md"
 Call Log
 SetOutPath "$NewDir\assets"
 ClearErrors
 File "/oname=Brisa-Azul.mp4" "${PAYLOAD_ROOT}\assets\Brisa-Azul.mp4"
 IfErrors install_fail
 IfFileExists "$NewDir\assets\Brisa-Azul.mp4" 0 install_fail
 Push "$(ExtractedText) assets\Brisa-Azul.mp4"
 Call Log
 SetOutPath "$NewDir\assets"
 ClearErrors
 File "/oname=LICENCA-EXEMPLO.txt" "${PAYLOAD_ROOT}\assets\LICENCA-EXEMPLO.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\assets\LICENCA-EXEMPLO.txt" 0 install_fail
 Push "$(ExtractedText) assets\LICENCA-EXEMPLO.txt"
 Call Log
 SetOutPath "$NewDir\assets"
 ClearErrors
 File "/oname=app.ico" "${PAYLOAD_ROOT}\assets\app.ico"
 IfErrors install_fail
 IfFileExists "$NewDir\assets\app.ico" 0 install_fail
 Push "$(ExtractedText) assets\app.ico"
 Call Log
 SetOutPath "$NewDir\docs"
 ClearErrors
 File "/oname=AJUDA.txt" "${PAYLOAD_ROOT}\docs\AJUDA.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\docs\AJUDA.txt" 0 install_fail
 Push "$(ExtractedText) docs\AJUDA.txt"
 Call Log
 SetOutPath "$NewDir\docs"
 ClearErrors
 File "/oname=ALTERACOES.md" "${PAYLOAD_ROOT}\docs\ALTERACOES.md"
 IfErrors install_fail
 IfFileExists "$NewDir\docs\ALTERACOES.md" 0 install_fail
 Push "$(ExtractedText) docs\ALTERACOES.md"
 Call Log
 SetOutPath "$NewDir\docs"
 ClearErrors
 File "/oname=Guia-pt-BR.html" "${PAYLOAD_ROOT}\docs\Guia-pt-BR.html"
 IfErrors install_fail
 IfFileExists "$NewDir\docs\Guia-pt-BR.html" 0 install_fail
 Push "$(ExtractedText) docs\Guia-pt-BR.html"
 Call Log
 SetOutPath "$NewDir\docs"
 ClearErrors
 File "/oname=Guia-pt-BR.md" "${PAYLOAD_ROOT}\docs\Guia-pt-BR.md"
 IfErrors install_fail
 IfFileExists "$NewDir\docs\Guia-pt-BR.md" 0 install_fail
 Push "$(ExtractedText) docs\Guia-pt-BR.md"
 Call Log
 SetOutPath "$NewDir\docs"
 ClearErrors
 File "/oname=Guia-pt-BR.pdf" "${PAYLOAD_ROOT}\docs\Guia-pt-BR.pdf"
 IfErrors install_fail
 IfFileExists "$NewDir\docs\Guia-pt-BR.pdf" 0 install_fail
 Push "$(ExtractedText) docs\Guia-pt-BR.pdf"
 Call Log
 SetOutPath "$NewDir\docs"
 ClearErrors
 File "/oname=Guide-en.html" "${PAYLOAD_ROOT}\docs\Guide-en.html"
 IfErrors install_fail
 IfFileExists "$NewDir\docs\Guide-en.html" 0 install_fail
 Push "$(ExtractedText) docs\Guide-en.html"
 Call Log
 SetOutPath "$NewDir\docs"
 ClearErrors
 File "/oname=Guide-en.md" "${PAYLOAD_ROOT}\docs\Guide-en.md"
 IfErrors install_fail
 IfFileExists "$NewDir\docs\Guide-en.md" 0 install_fail
 Push "$(ExtractedText) docs\Guide-en.md"
 Call Log
 SetOutPath "$NewDir\docs"
 ClearErrors
 File "/oname=Guide-en.pdf" "${PAYLOAD_ROOT}\docs\Guide-en.pdf"
 IfErrors install_fail
 IfFileExists "$NewDir\docs\Guide-en.pdf" 0 install_fail
 Push "$(ExtractedText) docs\Guide-en.pdf"
 Call Log
 SetOutPath "$NewDir\docs"
 ClearErrors
 File "/oname=HELP.txt" "${PAYLOAD_ROOT}\docs\HELP.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\docs\HELP.txt" 0 install_fail
 Push "$(ExtractedText) docs\HELP.txt"
 Call Log
 SetOutPath "$NewDir\ferramentas"
 ClearErrors
 File "/oname=ffmpeg.exe" "${PAYLOAD_ROOT}\ferramentas\ffmpeg.exe"
 IfErrors install_fail
 IfFileExists "$NewDir\ferramentas\ffmpeg.exe" 0 install_fail
 Push "$(ExtractedText) ferramentas\ffmpeg.exe"
 Call Log
 SetOutPath "$NewDir\ferramentas"
 ClearErrors
 File "/oname=ffprobe.exe" "${PAYLOAD_ROOT}\ferramentas\ffprobe.exe"
 IfErrors install_fail
 IfFileExists "$NewDir\ferramentas\ffprobe.exe" 0 install_fail
 Push "$(ExtractedText) ferramentas\ffprobe.exe"
 Call Log
 SetOutPath "$NewDir\fontes"
 ClearErrors
 File "/oname=PapelVivo-fontes.zip" "${PAYLOAD_ROOT}\fontes\PapelVivo-fontes.zip"
 IfErrors install_fail
 IfFileExists "$NewDir\fontes\PapelVivo-fontes.zip" 0 install_fail
 Push "$(ExtractedText) fontes\PapelVivo-fontes.zip"
 Call Log
 SetOutPath "$NewDir\fontes-terceiros"
 ClearErrors
 File "/oname=LEIA-ME.txt" "${PAYLOAD_ROOT}\fontes-terceiros\LEIA-ME.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\fontes-terceiros\LEIA-ME.txt" 0 install_fail
 Push "$(ExtractedText) fontes-terceiros\LEIA-ME.txt"
 Call Log
 SetOutPath "$NewDir\fontes-terceiros"
 ClearErrors
 File "/oname=fontes-principais.tar.gz" "${PAYLOAD_ROOT}\fontes-terceiros\fontes-principais.tar.gz"
 IfErrors install_fail
 IfFileExists "$NewDir\fontes-terceiros\fontes-principais.tar.gz" 0 install_fail
 Push "$(ExtractedText) fontes-terceiros\fontes-principais.tar.gz"
 Call Log
 SetOutPath "$NewDir"
 ClearErrors
 File "/oname=libmpv-2.dll" "${PAYLOAD_ROOT}\libmpv-2.dll"
 IfErrors install_fail
 IfFileExists "$NewDir\libmpv-2.dll" 0 install_fail
 Push "$(ExtractedText) libmpv-2.dll"
 Call Log
 SetOutPath "$NewDir\licencas"
 ClearErrors
 File "/oname=GPL-2.0.txt" "${PAYLOAD_ROOT}\licencas\GPL-2.0.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\licencas\GPL-2.0.txt" 0 install_fail
 Push "$(ExtractedText) licencas\GPL-2.0.txt"
 Call Log
 SetOutPath "$NewDir\licencas"
 ClearErrors
 File "/oname=GPL-3.0.txt" "${PAYLOAD_ROOT}\licencas\GPL-3.0.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\licencas\GPL-3.0.txt" 0 install_fail
 Push "$(ExtractedText) licencas\GPL-3.0.txt"
 Call Log
 SetOutPath "$NewDir\licencas"
 ClearErrors
 File "/oname=LGPL-2.1.txt" "${PAYLOAD_ROOT}\licencas\LGPL-2.1.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\licencas\LGPL-2.1.txt" 0 install_fail
 Push "$(ExtractedText) licencas\LGPL-2.1.txt"
 Call Log
 SetOutPath "$NewDir\licencas"
 ClearErrors
 File "/oname=LGPL-3.0.txt" "${PAYLOAD_ROOT}\licencas\LGPL-3.0.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\licencas\LGPL-3.0.txt" 0 install_fail
 Push "$(ExtractedText) licencas\LGPL-3.0.txt"
 Call Log
 SetOutPath "$NewDir\licencas"
 ClearErrors
 File "/oname=NSIS-copyright.txt" "${PAYLOAD_ROOT}\licencas\NSIS-copyright.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\licencas\NSIS-copyright.txt" 0 install_fail
 Push "$(ExtractedText) licencas\NSIS-copyright.txt"
 Call Log
 SetOutPath "$NewDir\licencas"
 ClearErrors
 File "/oname=PapelVivo-ate-1.0.2-MIT.txt" "${PAYLOAD_ROOT}\licencas\PapelVivo-ate-1.0.2-MIT.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\licencas\PapelVivo-ate-1.0.2-MIT.txt" 0 install_fail
 Push "$(ExtractedText) licencas\PapelVivo-ate-1.0.2-MIT.txt"
 Call Log
 SetOutPath "$NewDir\licencas"
 ClearErrors
 File "/oname=miniz-MIT.txt" "${PAYLOAD_ROOT}\licencas\miniz-MIT.txt"
 IfErrors install_fail
 IfFileExists "$NewDir\licencas\miniz-MIT.txt" 0 install_fail
 Push "$(ExtractedText) licencas\miniz-MIT.txt"
 Call Log
!macroend
!macro DeleteOwned BASE
 IfFileExists "${BASE}\LICENCA-PAPEL-VIVO.txt" 0 +5
 ClearErrors
 Delete "${BASE}\LICENCA-PAPEL-VIVO.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\LICENCAS-TERCEIROS.md" 0 +5
 ClearErrors
 Delete "${BASE}\LICENCAS-TERCEIROS.md"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\LICENSE-PAPEL-VIVO-en.txt" 0 +5
 ClearErrors
 Delete "${BASE}\LICENSE-PAPEL-VIVO-en.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\PapelVivo.exe" 0 +5
 ClearErrors
 Delete "${BASE}\PapelVivo.exe"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\README-en.md" 0 +5
 ClearErrors
 Delete "${BASE}\README-en.md"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\README.md" 0 +5
 ClearErrors
 Delete "${BASE}\README.md"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\THIRD-PARTY-LICENSES.md" 0 +5
 ClearErrors
 Delete "${BASE}\THIRD-PARTY-LICENSES.md"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\assets\Brisa-Azul.mp4" 0 +5
 ClearErrors
 Delete "${BASE}\assets\Brisa-Azul.mp4"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\assets\LICENCA-EXEMPLO.txt" 0 +5
 ClearErrors
 Delete "${BASE}\assets\LICENCA-EXEMPLO.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\assets\app.ico" 0 +5
 ClearErrors
 Delete "${BASE}\assets\app.ico"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\docs\AJUDA.txt" 0 +5
 ClearErrors
 Delete "${BASE}\docs\AJUDA.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\docs\ALTERACOES.md" 0 +5
 ClearErrors
 Delete "${BASE}\docs\ALTERACOES.md"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\docs\Guia-pt-BR.html" 0 +5
 ClearErrors
 Delete "${BASE}\docs\Guia-pt-BR.html"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\docs\Guia-pt-BR.md" 0 +5
 ClearErrors
 Delete "${BASE}\docs\Guia-pt-BR.md"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\docs\Guia-pt-BR.pdf" 0 +5
 ClearErrors
 Delete "${BASE}\docs\Guia-pt-BR.pdf"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\docs\Guide-en.html" 0 +5
 ClearErrors
 Delete "${BASE}\docs\Guide-en.html"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\docs\Guide-en.md" 0 +5
 ClearErrors
 Delete "${BASE}\docs\Guide-en.md"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\docs\Guide-en.pdf" 0 +5
 ClearErrors
 Delete "${BASE}\docs\Guide-en.pdf"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\docs\HELP.txt" 0 +5
 ClearErrors
 Delete "${BASE}\docs\HELP.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\ferramentas\ffmpeg.exe" 0 +5
 ClearErrors
 Delete "${BASE}\ferramentas\ffmpeg.exe"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\ferramentas\ffprobe.exe" 0 +5
 ClearErrors
 Delete "${BASE}\ferramentas\ffprobe.exe"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\fontes\PapelVivo-fontes.zip" 0 +5
 ClearErrors
 Delete "${BASE}\fontes\PapelVivo-fontes.zip"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\fontes-terceiros\LEIA-ME.txt" 0 +5
 ClearErrors
 Delete "${BASE}\fontes-terceiros\LEIA-ME.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\fontes-terceiros\fontes-principais.tar.gz" 0 +5
 ClearErrors
 Delete "${BASE}\fontes-terceiros\fontes-principais.tar.gz"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\libmpv-2.dll" 0 +5
 ClearErrors
 Delete "${BASE}\libmpv-2.dll"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\licencas\GPL-2.0.txt" 0 +5
 ClearErrors
 Delete "${BASE}\licencas\GPL-2.0.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\licencas\GPL-3.0.txt" 0 +5
 ClearErrors
 Delete "${BASE}\licencas\GPL-3.0.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\licencas\LGPL-2.1.txt" 0 +5
 ClearErrors
 Delete "${BASE}\licencas\LGPL-2.1.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\licencas\LGPL-3.0.txt" 0 +5
 ClearErrors
 Delete "${BASE}\licencas\LGPL-3.0.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\licencas\NSIS-copyright.txt" 0 +5
 ClearErrors
 Delete "${BASE}\licencas\NSIS-copyright.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\licencas\PapelVivo-ate-1.0.2-MIT.txt" 0 +5
 ClearErrors
 Delete "${BASE}\licencas\PapelVivo-ate-1.0.2-MIT.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 IfFileExists "${BASE}\licencas\miniz-MIT.txt" 0 +5
 ClearErrors
 Delete "${BASE}\licencas\miniz-MIT.txt"
 IfErrors 0 +2
 StrCpy $RemovalError 1
 RMDir "${BASE}\fontes-terceiros"
 RMDir "${BASE}\ferramentas"
 RMDir "${BASE}\licencas"
 RMDir "${BASE}\assets"
 RMDir "${BASE}\fontes"
 RMDir "${BASE}\docs"
!macroend
