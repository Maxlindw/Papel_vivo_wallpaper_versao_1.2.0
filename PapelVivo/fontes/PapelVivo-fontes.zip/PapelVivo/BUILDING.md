# Build / Compilação
C++17; CMake 3.20+; Windows x64; MinGW-w64 or MSVC.
cmake -S . -B build && cmake --build build --config Release
The active app uses src/main.cpp, src/player.cpp, src/media_job.cpp and assets/app.rc.
NSIS 3.08+ compiles installer/PapelVivo.nsi. Generate its explicit payload list using installer/gerar_payload.py.
Use absolute PAYLOAD_ROOT and OUTPUT_FILE definitions. Runtime libraries are distributed separately from these app sources.
Third-party license notices are in LICENCAS-TERCEIROS.md. The legacy standalone launcher is not part of this revision.
