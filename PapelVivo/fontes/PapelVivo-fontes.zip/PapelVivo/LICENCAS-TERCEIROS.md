# Licenças de terceiros / Third-party licenses

Papel Vivo 1.2.0 • componentes próprios / original components: kz.
As licenças dos componentes abaixo permanecem com seus autores. / The components below retain their authors’ licenses.

## Componentes e versões / Components and versions

| Componente / Component | Versão incluída / Included version | Licença aplicável / Applicable license | Fonte oficial / Official source |
| --- | --- | --- | --- |
| libmpv / mpv | v0.41.0-dev-ga2cd83c56; revisão a2cd83c56de859ced3fc8e6055e5878e50f45286 | Código-base elegível a LGPL-2.1-or-later; variante binária LGPLv3 com FFmpeg LGPLv3 / Base sources eligible for LGPL-2.1-or-later; this binary variant is LGPLv3 with LGPLv3 FFmpeg | https://github.com/mpv-player/mpv/tree/a2cd83c56de859ced3fc8e6055e5878e50f45286 |
| FFmpeg / ffprobe (conversão / conversion) | n8.1.3-18-g46d899d7a0; variante BtbN win64-gpl-8.1, 2026-10-16 | GPL-3.0-or-later nesta configuração, com libx264 / GPL-3.0-or-later in this configuration, including libx264 | https://github.com/FFmpeg/FFmpeg/tree/46d899d7a0 |
| FFmpeg dentro de / within libmpv | revisão / revision 513df1c | LGPL-3.0-or-later nesta configuração / in this configuration | https://github.com/FFmpeg/FFmpeg/tree/513df1c |
| miniz | cópia fornecida nos fontes, macro MZ_VERSION 11.0.2; não é uma dependência do player revisado / supplied source copy, MZ_VERSION macro 11.0.2; not a dependency of the revised player | MIT | https://github.com/richgel999/miniz |
| NSIS | 3.08; empacotamento / packaging | Termos dos componentes NSIS, incluídos integralmente / Component-specific NSIS terms, included in full | https://nsis.sourceforge.io/License |

FFmpeg em geral pode ser LGPL-2.1-or-later, mas a variante realmente distribuída aqui habilita GPL e versão 3. Ela não deve ser identificada como LGPL 2.1. A variante libmpv inclui FFmpeg com LGPL versão 3. / FFmpeg in general may be LGPL-2.1-or-later, but the actual conversion binaries supplied here enable GPL and version 3. They must not be labeled LGPL 2.1. This libmpv variant includes LGPL version 3 FFmpeg.

## Textos completos offline / Full offline texts

- licencas/GPL-3.0.txt — https://www.gnu.org/licenses/gpl-3.0.txt
- licencas/LGPL-3.0.txt — https://www.gnu.org/licenses/lgpl-3.0.txt (leia junto com GPL-3.0.txt / read with GPL-3.0.txt).
- licencas/LGPL-2.1.txt — https://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt
- licencas/GPL-2.0.txt — https://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
- licencas/miniz-MIT.txt — aviso original MIT / original MIT notice.
- licencas/NSIS-copyright.txt — termos originais do NSIS / original NSIS terms.
- licencas/PapelVivo-ate-1.0.2-MIT.txt — direitos do código preexistente preservados / existing code rights preserved.

Os textos legais originais são preservados sem cortes ou tradução substitutiva. / Original legal texts are preserved without redaction or replacement translations.

## Fontes e permissões / Sources and permissions

fontes-terceiros/fontes-principais.tar.gz inclui os fontes principais de mpv, as duas revisões FFmpeg e as receitas anteriormente arquivadas. fontes/PapelVivo-fontes.zip contém o código próprio revisado e a cópia de miniz. / fontes-terceiros/fontes-principais.tar.gz contains the main mpv sources, both FFmpeg revisions and the previously archived recipes. fontes/PapelVivo-fontes.zip contains the revised application sources and the supplied miniz copy.

Fontes oficiais adicionais / Additional official sources:
- mpv: https://github.com/mpv-player/mpv
- FFmpeg: https://ffmpeg.org/download.html ; https://ffmpeg.org/legal.html
- libx264: https://code.videolan.org/videolan/x264
- Receitas da distribuição FFmpeg / FFmpeg distribution recipes: https://github.com/BtbN/FFmpeg-Builds
- miniz: https://github.com/richgel999/miniz

É permitida a substituição de libmpv-2.dll por versão compatível e a depuração necessária a modificações da biblioteca. As licenças de terceiros prevalecem sobre restrições incompatíveis nos termos dos componentes próprios. / Replacing libmpv-2.dll with an ABI-compatible version and debugging library modifications are permitted. Third-party licenses prevail over conflicting restrictions in the original-component terms.

## Disponibilidade dos fontes / Source availability

Os fontes das bibliotecas de terceiros estão disponíveis nos links oficiais listados em [LICENCAS-TERCEIROS.md](LICENCAS-TERCEIROS.md).

Third-party library sources are available through the official links listed in [LICENCAS-TERCEIROS.md](LICENCAS-TERCEIROS.md) (English notice: [THIRD-PARTY-LICENSES.md](THIRD-PARTY-LICENSES.md)).

Os links oficiais não comprovam, por si só, a disponibilidade de todos os fontes correspondentes exigidos para os binários distribuídos; essa verificação permanece pendente. / Official links alone do not establish that all corresponding sources required for the distributed binaries are available; that verification remains pending.

Crédito adicional / Additional acknowledgement: esta distribuição de FFmpeg pode incluir código baseado no trabalho do Independent JPEG Group (IJG); os arquivos originais de terceiros não foram alterados nesta revisão. / This FFmpeg distribution may include code based on the work of the Independent JPEG Group (IJG); third-party binary/source files were not modified in this revision.
