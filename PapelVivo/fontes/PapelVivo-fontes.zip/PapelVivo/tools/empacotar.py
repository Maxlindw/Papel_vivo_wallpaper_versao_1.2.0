"""Cria ZIP incorporável. Executar antes de reconfigurar o CMake do launcher."""
from pathlib import Path
import hashlib, sys, zipfile, json
root=Path(__file__).resolve().parents[1]
payload=Path(sys.argv[1]).resolve();out=root/'assets/payload.zip'
manifest={str(p.relative_to(payload)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in payload.rglob('*') if p.is_file() and p.name!='integridade.json'}
(payload/'integridade.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(payload.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(payload)).replace('\\','/'))
sha=hashlib.sha256(out.read_bytes()).hexdigest()
(root/'include/payload_version.hpp').write_text('#pragma once\n#define PAYLOAD_VERSION L"1.1.0-'+sha[:12]+'"\n#define PAYLOAD_HASH "'+sha+'"\n')
(root/'assets/payload.rc').write_text('201 RCDATA "payload.zip"\n')
print('Pacote:',out.stat().st_size,'bytes; SHA-256:',sha)
