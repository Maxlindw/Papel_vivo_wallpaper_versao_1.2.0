﻿# Obtém ferramentas locais; não instala codecs nem altera o PATH.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$meta = Get-Content -LiteralPath (Join-Path $root 'docs\ffmpeg-versao.json') -Raw | ConvertFrom-Json
$dest = Join-Path $root 'ferramentas'
$tmp = $null
try {
    $complete = $true
    foreach ($name in @('ffmpeg','ffprobe')) {
        $file = Join-Path $dest ($name + '.exe')
        if (-not (Test-Path -LiteralPath $file)) { $complete = $false; continue }
        $expected = $meta.('sha256_' + $name)
        if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) {
            throw ('Existe uma ferramenta diferente em ' + $file + '. Ela não foi sobrescrita. Consulte o README.')
        }
    }
    if (-not $complete) {
        Write-Host 'Baixando FFmpeg/ffprobe x64 (aprox. 193 MB) para verificar e converter vídeos offline...'
        Write-Host $meta.url
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $tmp = Join-Path ([IO.Path]::GetTempPath()) ('PapelVivo-FFmpeg-' + [Guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $tmp | Out-Null
        $zip = Join-Path $tmp 'ffmpeg.zip'
        Invoke-WebRequest -Uri $meta.url -OutFile $zip -UseBasicParsing
        if ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant() -ne $meta.sha256_zip) { throw 'SHA-256 do pacote FFmpeg não confere. Nada foi executado.' }
        $expanded = Join-Path $tmp 'extraido'
        Expand-Archive -LiteralPath $zip -DestinationPath $expanded
        $files = @{}
        # Confere AMBOS antes de copiar. Nunca usa um ffmpeg encontrado no PATH.
        foreach ($name in @('ffmpeg','ffprobe')) {
            $candidate = @(Get-ChildItem -LiteralPath $expanded -Recurse -File -Filter ($name + '.exe'))
            if ($candidate.Count -ne 1) { throw ('Pacote ambíguo ou sem ' + $name) }
            $expected = $meta.('sha256_' + $name)
            if ((Get-FileHash -LiteralPath $candidate[0].FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) { throw ('SHA-256 de ' + $name + ' não confere.') }
            $files[$name] = $candidate[0].FullName
        }
        New-Item -ItemType Directory -Path $dest -Force | Out-Null
        foreach ($name in @('ffmpeg','ffprobe')) { Copy-Item -LiteralPath $files[$name] -Destination (Join-Path $dest ($name + '.exe')) }
        $licenses = Join-Path $root 'third_party\ffmpeg'
        New-Item -ItemType Directory -Path $licenses -Force | Out-Null
        $package = Split-Path -Parent (Split-Path -Parent $files['ffmpeg'])
        foreach ($legal in @('LICENSE.txt','README.txt','doc')) {
            $source = Join-Path $package $legal
            if (Test-Path -LiteralPath $source) { Copy-Item -LiteralPath $source -Destination $licenses -Recurse -Force }
        }
        Write-Host 'Ferramentas verificadas. A verificação/conversão não depende de internet.'
    }
} finally {
    if ($tmp -and (Test-Path -LiteralPath $tmp)) { Remove-Item -LiteralPath $tmp -Recurse -Force }
}
