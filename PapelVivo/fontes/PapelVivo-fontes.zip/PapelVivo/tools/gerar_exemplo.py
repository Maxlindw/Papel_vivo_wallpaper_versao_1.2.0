"""Gera Brisa Azul: gradiente animado original, em loop, sem mídia de terceiros.
Requer numpy e FFmpeg na máquina de DESENVOLVIMENTO, não no PC do usuário.
"""
from pathlib import Path
import subprocess
import numpy as np
root=Path(__file__).resolve().parents[1]
out=root/'assets/Brisa-Azul.mp4'
w,h,fps,seconds=1280,720,30,10
x=np.linspace(-1,1,w,dtype=np.float32)[None,:]
y=np.linspace(-1,1,h,dtype=np.float32)[:,None]
cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{w}x{h}','-framerate',str(fps),'-i','-','-an','-c:v','libx264','-preset','medium','-crf','23','-pix_fmt','yuv420p','-movflags','+faststart',str(out)]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for i in range(fps*seconds):
    t=2*np.pi*i/(fps*seconds)
    glow=np.exp(-((x-.45*np.cos(t))**2+(y-.35*np.sin(t))**2)*2)
    wave=(np.sin(2.1*x+1.3*y+.35*np.sin(t))+1)*.5
    light=np.exp(-((y-.22*np.sin(3*x+t))/.32)**2)
    arr=np.stack([np.broadcast_to(11+16*glow+7*light,(h,w)),
                  25+55*glow+16*wave+14*light,
                  46+60*glow+35*wave+12*light],axis=2)
    p.stdin.write(np.clip(arr,0,255).astype('uint8').tobytes())
p.stdin.close()
if p.wait():raise SystemExit('Erro FFmpeg')
print(out.name,out.stat().st_size,'bytes; H.264, 720p, 30 FPS, 10 s')
