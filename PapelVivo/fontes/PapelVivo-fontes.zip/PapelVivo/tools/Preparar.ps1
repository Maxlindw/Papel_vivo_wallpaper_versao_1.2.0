﻿# Preparação local: sem administrador, sem instalador e sem alterar o PATH.
# A biblioteca vem DIRETAMENTE do projeto mpv. SHA-256 conferido antes de usar.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$meta = Get-Content -LiteralPath (Join-Path $root 'docs\libmpv-versao.json') -Raw | ConvertFrom-Json
$dll = Join-Path $root 'libmpv-2.dll'
$tmp = $null
try {
    if (Test-Path -LiteralPath $dll) {
        if ((Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash.ToLowerInvariant() -ne $meta.sha256_dll) {
            throw 'Já há uma DLL diferente nesta pasta. Ela não foi sobrescrita. Consulte o README.'
        }
    } else {
        Write-Host 'Preparando Papel Vivo. Baixando libmpv x64 do GitHub oficial (aprox. 57 MB)...'
        Write-Host $meta.url
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $tmp = Join-Path ([IO.Path]::GetTempPath()) ('PapelVivo-' + [Guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $tmp | Out-Null
        $zip = Join-Path $tmp 'libmpv.zip'
        Invoke-WebRequest -Uri $meta.url -OutFile $zip -UseBasicParsing
        if ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant() -ne $meta.sha256_zip) {
            throw 'O arquivo baixado não confere com o SHA-256 esperado. Nada foi executado.'
        }
        $expanded = Join-Path $tmp 'arquivos'
        Expand-Archive -LiteralPath $zip -DestinationPath $expanded
        $candidate = Join-Path $expanded 'libmpv-2.dll'
        if ((Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToLowerInvariant() -ne $meta.sha256_dll) {
            throw 'A DLL extraída não confere com a versão testada.'
        }
        $third = Join-Path $root 'third_party'
        New-Item -ItemType Directory -Path $third -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $expanded 'LICENSE.LGPL') -Destination $third
        Copy-Item -LiteralPath $candidate -Destination $dll
        Write-Host 'Biblioteca verificada e salva somente nesta pasta.'
    }
    & (Join-Path $PSScriptRoot 'Preparar-FFmpeg.ps1')
    $exe = Join-Path $root 'PapelVivo.exe'
    if (-not (Test-Path -LiteralPath $exe)) { throw 'PapelVivo.exe não encontrado. Use o pacote portátil ou compile o código.' }
    $sample = Join-Path $root 'assets\Brisa-Azul.mp4'
    if (Test-Path -LiteralPath $sample) {
        Start-Process -FilePath $exe -ArgumentList @('--visualizar', ('"' + $sample + '"'))
    } else { Start-Process -FilePath $exe }
} catch {
    Write-Host ('Falha na preparação: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Se o GitHub remover este snapshot, use a versão compatível descrita no README. Não há atualização silenciosa para outra DLL.'
    exit 1
} finally {
    if ($tmp -and (Test-Path -LiteralPath $tmp)) { Remove-Item -LiteralPath $tmp -Recurse -Force }
}
